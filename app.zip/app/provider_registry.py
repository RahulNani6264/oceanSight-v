from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .ocean_variables import get_variable_catalog, normalize_variable_name

@dataclass(frozen=True)
class ProviderSpec:
    provider: str
    dataset: str
    kind: str
    status: str
    coverage: str
    notes: str

_DEFAULT = ProviderSpec('unconfigured', 'none', 'scalar', 'unavailable', 'unknown', 'No connected real-data adapter is configured for this variable.')
_PROVIDER_BY_VARIABLE = {
    'temperature': ProviderSpec('HYCOM/INCOIS', 'RSMC_hycom', 'scalar', 'connected', 'catalog-defined', 'Real ocean temperature source.'),
    'salinity': ProviderSpec('HYCOM/INCOIS', 'RSMC_hycom', 'scalar', 'connected', 'catalog-defined', 'Real ocean salinity source.'),
    'current_u': ProviderSpec('HYCOM/INCOIS', 'RSMC_hycom', 'vector-component', 'connected', 'catalog-defined', 'Eastward current component.'),
    'current_v': ProviderSpec('HYCOM/INCOIS', 'RSMC_hycom', 'vector-component', 'connected', 'catalog-defined', 'Northward current component.'),
    'current_speed': ProviderSpec('derived/HYCOM', 'RSMC_hycom', 'scalar-derived', 'connected', 'catalog-defined', 'Derived from current_u/current_v.'),
    'current_direction': ProviderSpec('derived/HYCOM', 'RSMC_hycom', 'scalar-derived', 'connected', 'catalog-defined', 'Derived from current_u/current_v.'),
}

def provider_for(variable: str) -> dict[str, Any]:
    key = normalize_variable_name(variable)
    return asdict(_PROVIDER_BY_VARIABLE.get(key, _DEFAULT)) | {'variable': key}

def catalog_with_providers() -> list[dict[str, Any]]:
    result = []
    for item in get_variable_catalog():
        key = item.get('id') or item.get('variable') or item.get('name')
        enriched = dict(item)
        if key:
            enriched['provider'] = provider_for(str(key))
        result.append(enriched)
    return result
