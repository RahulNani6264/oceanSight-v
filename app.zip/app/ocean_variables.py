from __future__ import annotations

from copy import deepcopy
from typing import Any


# =============================================================================
# OCEANSIGHT-V
# UNIFIED SCIENTIFIC VARIABLE CATALOG
#
# This module describes the variables that the backend can expose without
# inventing data.  "connected" means that the current OceanSight backend has
# a real source/service path for that variable.  Variables that are requested
# by the product but are not yet connected are kept in the catalog with
# connected=False rather than being silently mapped to another field.
# =============================================================================


_VARIABLES: tuple[dict[str, Any], ...] = (
    {
        "id": "temperature",
        "name": "Temperature",
        "short_name": "TEMP",
        "unit": "degree_Celsius",
        "category": "ocean",
        "source": {
            "provider": "INCOIS",
            "dataset": "RSMC HYCOM",
            "field": "TEMP",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "depth_levels",
            "depth_unit": "m",
            "real_source_levels_m": [0.0, 10.0, 50.0, 100.0, 250.0, 500.0],
        },
        "render": {
            "kind": "scalar",
            "color_scale": [
                "#313695",
                "#4575B4",
                "#74ADD1",
                "#ABD9E9",
                "#E0F3F8",
                "#FFFFBF",
                "#FEE090",
                "#FDAE61",
                "#F46D43",
                "#D73027",
            ],
        },
    },
    {
        "id": "salinity",
        "name": "Salinity",
        "short_name": "SALN",
        "unit": "PSU",
        "category": "ocean",
        "source": {
            "provider": "INCOIS",
            "dataset": "RSMC HYCOM",
            "field": "SALN",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "depth_levels",
            "depth_unit": "m",
            "real_source_levels_m": [0.0, 10.0, 50.0, 100.0, 250.0, 500.0],
        },
        "render": {
            "kind": "scalar",
            "color_scale": [
                "#440154",
                "#482878",
                "#3E4989",
                "#31688E",
                "#26828E",
                "#35B779",
                "#6CCE59",
                "#B4DE2C",
                "#FDE725",
            ],
        },
    },
    {
        "id": "current_u",
        "name": "Eastward Current",
        "short_name": "UVEL",
        "unit": "m/s",
        "category": "ocean_current",
        "source": {
            "provider": "INCOIS",
            "dataset": "RSMC HYCOM",
            "field": "UVEL",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "depth_levels",
            "depth_unit": "m",
            "real_source_levels_m": [0.0, 10.0, 50.0, 100.0, 250.0, 500.0],
        },
        "render": {
            "kind": "vector_component",
            "color_scale": [
                "#313695",
                "#4575B4",
                "#74ADD1",
                "#E0F3F8",
                "#FFFFBF",
                "#FEE090",
                "#F46D43",
                "#A50026",
            ],
        },
    },
    {
        "id": "current_v",
        "name": "Northward Current",
        "short_name": "VVEL",
        "unit": "m/s",
        "category": "ocean_current",
        "source": {
            "provider": "INCOIS",
            "dataset": "RSMC HYCOM",
            "field": "VVEL",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "depth_levels",
            "depth_unit": "m",
            "real_source_levels_m": [0.0, 10.0, 50.0, 100.0, 250.0, 500.0],
        },
        "render": {
            "kind": "vector_component",
            "color_scale": [
                "#313695",
                "#4575B4",
                "#74ADD1",
                "#E0F3F8",
                "#FFFFBF",
                "#FEE090",
                "#F46D43",
                "#A50026",
            ],
        },
    },
    {
        "id": "current_speed",
        "name": "Current Speed",
        "short_name": "SPEED",
        "unit": "m/s",
        "category": "ocean_current",
        "source": {
            "type": "derived",
            "fields": ["UVEL", "VVEL"],
            "formula": "sqrt(UVEL^2 + VVEL^2)",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "depth_levels",
            "depth_unit": "m",
            "real_source_levels_m": [0.0, 10.0, 50.0, 100.0, 250.0, 500.0],
        },
        "render": {
            "kind": "derived_scalar",
            "color_scale": [
                "#0D0887",
                "#46039F",
                "#7201A8",
                "#9C179E",
                "#BD3786",
                "#D8576B",
                "#ED7953",
                "#FB9F3A",
                "#F0F921",
            ],
        },
    },
    {
        "id": "current_direction",
        "name": "Current Direction",
        "short_name": "DIR",
        "unit": "degree",
        "category": "ocean_current",
        "source": {
            "type": "derived",
            "fields": ["UVEL", "VVEL"],
            "formula": "atan2(VVEL, UVEL)",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "depth_levels",
            "depth_unit": "m",
            "real_source_levels_m": [0.0, 10.0, 50.0, 100.0, 250.0, 500.0],
        },
        "render": {
            "kind": "derived_direction",
            "color_scale": [
                "#440154",
                "#482878",
                "#3E4989",
                "#31688E",
                "#26828E",
                "#35B779",
                "#6CCE59",
                "#B4DE2C",
                "#FDE725",
            ],
        },
    },
    {
        "id": "sea_surface_height",
        "name": "Sea Surface Height",
        "short_name": "SSH",
        "unit": "m",
        "category": "ocean",
        "source": {
            "provider": "INCOIS",
            "dataset": "RSMC HYCOM",
            "field": "SSH",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": False,
            "mode": "surface_only",
            "depth_unit": "m",
            "real_source_levels_m": [0.0],
        },
        "render": {
            "kind": "scalar",
            "color_scale": [
                "#313695",
                "#74ADD1",
                "#E0F3F8",
                "#FFFFBF",
                "#FDAE61",
                "#D73027",
            ],
        },
    },
    {
        "id": "bathymetry",
        "name": "Bathymetry",
        "short_name": "elevation",
        "unit": "m",
        "category": "bathymetry",
        "source": {
            "provider": "GEBCO",
            "dataset": "GEBCO_2026",
            "field": "elevation",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "seafloor",
            "depth_unit": "m",
        },
        "render": {
            "kind": "terrain",
            "color_scale": [
                "#0B1D26",
                "#123C50",
                "#155E75",
                "#1D8A99",
                "#70C1B3",
                "#D9E8A8",
                "#C7B299",
                "#8C6A5D",
            ],
        },
    },
    {
        "id": "argo_temperature",
        "name": "Argo Temperature",
        "short_name": "TEMP",
        "unit": "degree_Celsius",
        "category": "observation",
        "source": {
            "provider": "INCOIS",
            "dataset": "Indian_ARGO_Floats",
            "field": "temperature",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "profile_pressure_levels",
            "depth_unit": "dbar",
            "scientific_note": "ARGO PRES is preserved as source pressure and is not silently converted to depth.",
        },
        "render": {
            "kind": "sensor_scalar",
            "color_scale": [
                "#313695",
                "#4575B4",
                "#74ADD1",
                "#E0F3F8",
                "#FFFFBF",
                "#FDAE61",
                "#D73027",
            ],
        },
    },
    {
        "id": "argo_salinity",
        "name": "Argo Salinity",
        "short_name": "SAL",
        "unit": "PSU",
        "category": "observation",
        "source": {
            "provider": "INCOIS",
            "dataset": "Indian_ARGO_Floats",
            "field": "salinity",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "profile_pressure_levels",
            "depth_unit": "dbar",
            "scientific_note": "ARGO PRES is preserved as source pressure and is not silently converted to depth.",
        },
        "render": {
            "kind": "sensor_scalar",
            "color_scale": [
                "#440154",
                "#482878",
                "#3E4989",
                "#31688E",
                "#26828E",
                "#35B779",
                "#B4DE2C",
                "#FDE725",
            ],
        },
    },
    {
        "id": "argo_pressure",
        "name": "Argo Pressure",
        "short_name": "PRES",
        "unit": "dbar",
        "category": "observation",
        "source": {
            "provider": "INCOIS",
            "dataset": "Indian_ARGO_Floats",
            "field": "pressure",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": True,
            "mode": "profile_pressure_levels",
            "depth_unit": "dbar",
            "scientific_note": "Pressure remains dbar from the source; no silent pressure-to-depth conversion is performed.",
        },
        "render": {
            "kind": "sensor_scalar",
            "color_scale": [
                "#0D0887",
                "#4C02A1",
                "#7E03A8",
                "#AA2396",
                "#CC4778",
                "#E66C5C",
                "#F99B3B",
                "#F0F921",
            ],
        },
    },
    # -------------------------------------------------------------------------
    # Requested product variables that do not yet have a connected source in
    # the current backend. They remain explicit so the frontend can show them
    # as planned/unavailable instead of receiving fabricated observations.
    # -------------------------------------------------------------------------
    {
        "id": "wind",
        "name": "Wind",
        "short_name": "WIND",
        "unit": "m/s",
        "category": "atmosphere",
        "source": {
            "provider": "NOAA NCEP",
            "dataset": "NCEP_Global_Best",
            "fields": ["ugrd10m", "vgrd10m"],
            "service": "public NOAA ERDDAP",
            "description": "10 m eastward and northward atmospheric wind components from the global GFS forecast collection.",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": False,
            "mode": "surface_only",
            "depth_unit": "m",
        },
        "render": {
            "kind": "vector",
            "color_scale": [
                "#313695", "#74ADD1", "#FFFFBF", "#F46D43", "#A50026"
            ],
        },
    },
    {
        "id": "air_pressure",
        "name": "Air Pressure",
        "short_name": "MSLP",
        "unit": "hPa",
        "category": "atmosphere",
        "source": {
            "provider": "NOAA NCEP",
            "dataset": "NCEP_Global_Best",
            "field": "prmslmsl",
            "service": "public NOAA ERDDAP",
            "description": "Mean sea-level atmospheric pressure from the global GFS forecast collection.",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": False,
            "mode": "surface_only",
            "depth_unit": "m",
        },
        "render": {
            "kind": "scalar",
            "color_scale": [
                "#313695", "#74ADD1", "#E0F3F8", "#FFFFBF", "#FDAE61", "#D73027"
            ],
        },
    },
    {
        "id": "chlorophyll",
        "name": "Chlorophyll",
        "short_name": "CHL",
        "unit": "mg/m^3",
        "category": "ocean_biogeochemistry",
        "source": {
            "provider": "NOAA NESDIS CoastWatch",
            "dataset": "noaacwNPPN20VIIRSDINEOFDaily",
            "field": "chlor_a",
            "service": "public NOAA ERDDAP",
            "description": "Gap-filled DINEOF near-real-time VIIRS chlorophyll-a global daily product.",
        },
        "connected": True,
        "live_capable": True,
        "vertical": {
            "supported": False,
            "mode": "surface_only",
            "depth_unit": "m",
        },
        "render": {
            "kind": "scalar",
            "color_scale": [
                "#440154", "#482878", "#3E4989", "#31688E", "#35B779", "#B4DE2C", "#FDE725"
            ],
        },
    },
)


_ALIASES: dict[str, str] = {
    "temp": "temperature",
    "temperature": "temperature",
    "sst": "temperature",
    "sal": "salinity",
    "salinity": "salinity",
    "saln": "salinity",
    "current_u": "current_u",
    "uvel": "current_u",
    "u": "current_u",
    "eastward_current": "current_u",
    "current_v": "current_v",
    "vvel": "current_v",
    "v": "current_v",
    "northward_current": "current_v",
    "current_speed": "current_speed",
    "speed": "current_speed",
    "current_direction": "current_direction",
    "direction": "current_direction",
    "ssh": "sea_surface_height",
    "sea_surface_height": "sea_surface_height",
    "bathymetry": "bathymetry",
    "elevation": "bathymetry",
    "argo_temperature": "argo_temperature",
    "argo_salinity": "argo_salinity",
    "argo_pressure": "argo_pressure",
    "pres": "argo_pressure",
    "wind": "wind",
    "mslp": "air_pressure",
    "air_pressure": "air_pressure",
    "pressure": "air_pressure",
    "chlorophyll": "chlorophyll",
    "chl": "chlorophyll",
}


def normalize_variable_name(variable: str) -> str:
    value = str(variable).strip().lower().replace("-", "_").replace(" ", "_")
    if not value:
        raise ValueError("variable cannot be empty.")
    try:
        return _ALIASES[value]
    except KeyError as exc:
        supported = ", ".join(item["id"] for item in _VARIABLES)
        raise ValueError(
            f"Unsupported variable '{variable}'. Supported variable ids: {supported}."
        ) from exc


def get_variable_catalog() -> list[dict[str, Any]]:
    return deepcopy(list(_VARIABLES))


def get_variable_definition(variable: str) -> dict[str, Any]:
    normalized = normalize_variable_name(variable)
    for item in _VARIABLES:
        if item["id"] == normalized:
            return deepcopy(item)
    raise ValueError(f"Variable '{variable}' is not defined in the catalog.")
