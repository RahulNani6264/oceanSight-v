from __future__ import annotations

import math
from copy import deepcopy
from typing import Any, Sequence

from .ocean_bathymetry import OceanBathymetryEngine
from .ocean_geometry import OceanGeometryEngine
from .ocean_volume import OceanVolumeEngine
from .ocean_variables import get_variable_definition, normalize_variable_name
from .ocean_external import OceanExternalDataEngine


DEFAULT_RADIUS_KM = 50.0
MAX_RADIUS_KM = 2000.0


class OceanDataEngine:
    """Route the fresh frontend's scientific-data requests to real engines."""

    DIRECT_HYCOM = {
        "temperature": "TEMP",
        "salinity": "SALN",
        "current_u": "UVEL",
        "current_v": "VVEL",
        "sea_surface_height": "SSH",
    }
    DERIVED = {"current_speed", "current_direction"}

    def __init__(self, *, volume_engine: OceanVolumeEngine, bathymetry_engine: OceanBathymetryEngine, geometry_engine: OceanGeometryEngine, external_engine: OceanExternalDataEngine | None = None) -> None:
        self.volume_engine = volume_engine
        self.bathymetry_engine = bathymetry_engine
        self.geometry_engine = geometry_engine
        self.external_engine = external_engine or OceanExternalDataEngine(geometry_engine=geometry_engine)

    @staticmethod
    def _lat(value: float) -> float:
        value = float(value)
        if not math.isfinite(value) or not -90 <= value <= 90:
            raise ValueError("latitude must be between -90 and 90 degrees.")
        return value

    @staticmethod
    def _lon(value: float) -> float:
        value = float(value)
        if not math.isfinite(value):
            raise ValueError("longitude must be finite.")
        return ((value + 180.0) % 360.0) - 180.0

    @staticmethod
    def _radius_bbox(latitude: float, longitude: float, radius_km: float) -> dict[str, float]:
        if not math.isfinite(radius_km) or radius_km <= 0 or radius_km > MAX_RADIUS_KM:
            raise ValueError(f"radius_km must be greater than zero and no more than {MAX_RADIUS_KM} km.")
        km_per_degree = 111.1950802335
        delta_lat = radius_km / km_per_degree
        cos_lat = max(0.01, math.cos(math.radians(latitude)))
        delta_lon = min(180.0, radius_km / (km_per_degree * cos_lat))
        return {
            "latitude_min": max(-90.0, latitude - delta_lat),
            "latitude_max": min(90.0, latitude + delta_lat),
            "longitude_min": longitude - delta_lon,
            "longitude_max": longitude + delta_lon,
        }

    @staticmethod
    def _geometry_bbox(boundary: Any) -> dict[str, float]:
        if boundary.bounding_box is None:
            raise LookupError("Selected ocean has no real boundary bounding box.")
        b = boundary.bounding_box
        return {
            "latitude_min": float(b["min_latitude"]),
            "latitude_max": float(b["max_latitude"]),
            "longitude_min": float(b["min_longitude"]),
            "longitude_max": float(b["max_longitude"]),
        }

    @staticmethod
    def _depths(depths_m: Sequence[float] | None) -> list[float] | None:
        if depths_m is None:
            return None
        values = sorted({round(float(d), 6) for d in depths_m})
        if not values or values[0] < 0:
            raise ValueError("depths_m must contain positive or zero numeric depths.")
        return values

    def _select(self, *, mode: str, ocean: str | None, latitude: float | None, longitude: float | None, radius_km: float, bbox: dict[str, float] | None = None) -> tuple[str, dict[str, Any], dict[str, float]]:
        mode = str(mode).strip().lower()
        if mode not in {"ocean", "block"}:
            raise ValueError("mode must be 'ocean' or 'block'.")
        lat = None if latitude is None else self._lat(latitude)
        lon = None if longitude is None else self._lon(longitude)
        identification = None

        if lat is not None or lon is not None:
            if lat is None or lon is None:
                raise ValueError("latitude and longitude must be supplied together.")
            from .ocean_regions import OceanRegionEngine
            identification = OceanRegionEngine().identify_dict(latitude=lat, longitude=lon)
            if not identification.get("available"):
                raise LookupError("The coordinate is not identified as an ocean by the real RECCAP2 mask.")
            detected = identification.get("ocean") or {}
            selected = detected.get("name")
            if not selected:
                raise LookupError("The coordinate did not resolve to a supported ocean.")
        elif ocean:
            selected, _ = self.geometry_engine.normalize_ocean_name(ocean)
        elif bbox is not None:
            center_lat = (bbox["latitude_min"] + bbox["latitude_max"]) / 2.0
            center_lon = (bbox["longitude_min"] + bbox["longitude_max"]) / 2.0
            from .ocean_regions import OceanRegionEngine
            identification = OceanRegionEngine().identify_dict(latitude=center_lat, longitude=center_lon)
            if not identification.get("available"):
                raise LookupError("The requested bounding box is not identified as a supported ocean by the real RECCAP2 mask.")
            selected = (identification.get("ocean") or {}).get("name")
            if not selected:
                raise LookupError("The requested bounding box did not resolve to a supported ocean.")
        else:
            raise ValueError("Provide ocean or latitude and longitude.")

        boundary = self.geometry_engine.boundary(selected)
        if not boundary.available or boundary.geometry is None:
            raise LookupError(f"No real ocean boundary is available for {selected}.")
        # Preserve an explicitly requested global bounding box. Only derive a
        # bounding box from the selected ocean geometry when the caller did not
        # provide one.
        if bbox is None:
            bbox = self._radius_bbox(lat, lon, radius_km) if mode == "block" else self._geometry_bbox(boundary)
        else:
            bbox = {
                "latitude_min": float(bbox["latitude_min"]),
                "latitude_max": float(bbox["latitude_max"]),
                "longitude_min": float(bbox["longitude_min"]),
                "longitude_max": float(bbox["longitude_max"]),
            }
            if bbox["latitude_min"] > bbox["latitude_max"] or bbox["longitude_min"] > bbox["longitude_max"]:
                raise ValueError("Bounding-box minimum cannot exceed maximum.")
        selection = {
            "mode": mode,
            "ocean": selected,
            "coordinate": None if lat is None or lon is None else {
                "latitude": lat, "longitude": lon, "coordinate_reference_system": "EPSG:4326"
            },
            "radius_km": float(radius_km) if mode == "block" else None,
            "identification": identification,
            "boundary": deepcopy(boundary.geometry),
            "bounding_box": bbox,
        }
        return selected, selection, bbox

    @staticmethod
    def _derive_levels(u: dict[str, Any], v: dict[str, Any], direction: bool) -> list[dict[str, Any]]:
        u_levels, v_levels = u.get("levels", []), v.get("levels", [])
        if len(u_levels) != len(v_levels):
            raise RuntimeError("UVEL and VVEL returned different depth counts.")
        result = []
        for ul, vl in zip(u_levels, v_levels):
            if ul.get("latitudes") != vl.get("latitudes") or ul.get("longitudes") != vl.get("longitudes"):
                raise RuntimeError("UVEL and VVEL returned different source grids.")
            vals, missing = [], []
            valid_count = 0
            for ru, rv, rw, rmu, rmv in zip(ul["values"], vl["values"], ul["water_mask"], ul["missing_mask"], vl["missing_mask"]):
                out_row, miss_row = [], []
                for uu, vv, water, mu, mv in zip(ru, rv, rw, rmu, rmv):
                    valid = bool(water) and not mu and not mv and uu is not None and vv is not None
                    if not valid:
                        out_row.append(None); miss_row.append(True); continue
                    uval, vval = float(uu), float(vv)
                    value = math.degrees(math.atan2(vval, uval)) if direction else math.hypot(uval, vval)
                    if direction and value < 0: value += 360.0
                    out_row.append(float(value)); miss_row.append(False); valid_count += 1
                vals.append(out_row); missing.append(miss_row)
            result.append({
                "requested_depth_m": ul.get("requested_depth_m"),
                "actual_depth_m": ul.get("actual_depth_m"),
                "units": "degree" if direction else "m/s",
                "latitudes": deepcopy(ul.get("latitudes", [])),
                "longitudes": deepcopy(ul.get("longitudes", [])),
                "values": vals,
                "missing_mask": missing,
                "water_mask": deepcopy(ul.get("water_mask", [])),
                "valid_value_count": valid_count,
                "actual_time_utc": ul.get("actual_time_utc"),
                "source": {"provider": "INCOIS", "dataset": "RSMC HYCOM", "fields": ["UVEL", "VVEL"]},
            })
        return result

    def build_data(self, *, mode: str, ocean: str | None, latitude: float | None, longitude: float | None, radius_km: float, time_utc: str, variable: str, depths_m: Sequence[float] | None, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        canonical = normalize_variable_name(variable)
        definition = get_variable_definition(canonical)
        if not definition.get("connected"):
            raise NotImplementedError(f"Variable '{canonical}' is cataloged but has no connected real-data provider yet.")

        selected, selection, bbox = self._select(mode=mode, ocean=ocean, latitude=latitude, longitude=longitude, radius_km=radius_km, bbox=bbox)
        if bbox is not None:
            bbox = {k: float(bbox[k]) for k in ("latitude_min", "latitude_max", "longitude_min", "longitude_max")}
            selection["bounding_box"] = bbox
        depth_values = self._depths(depths_m)

        if canonical == "bathymetry":
            payload = self.bathymetry_engine.build_surface(
                ocean=selected,
                latitude_min=bbox["latitude_min"], latitude_max=bbox["latitude_max"],
                longitude_min=bbox["longitude_min"], longitude_max=bbox["longitude_max"],
            )
            return {"available": True, "selection": selection, "variable": definition, "data_kind": "bathymetry_surface", "data": payload, "scientific_rules": {"synthetic_data": False, "interpolation": False}}

        if canonical in {"wind", "air_pressure", "chlorophyll"}:
            payload = self.external_engine.build_data(
                ocean=selected,
                latitude_min=bbox["latitude_min"],
                latitude_max=bbox["latitude_max"],
                longitude_min=bbox["longitude_min"],
                longitude_max=bbox["longitude_max"],
                time_utc=time_utc,
                variable=canonical,
            )
            return {
                "available": True,
                "selection": selection,
                "variable": definition,
                "data_kind": "external_surface_grid",
                "data": payload,
                "scientific_rules": {
                    "synthetic_data": False,
                    "interpolation": False,
                    "real_external_provider": True,
                },
            }

        if canonical in self.DIRECT_HYCOM:
            payload = self.volume_engine.build_volume(
                ocean=selected,
                latitude_min=bbox["latitude_min"], latitude_max=bbox["latitude_max"],
                longitude_min=bbox["longitude_min"], longitude_max=bbox["longitude_max"],
                time_utc=time_utc, variable=self.DIRECT_HYCOM[canonical], depths_m=depth_values,
            )
            return {"available": True, "selection": selection, "variable": definition, "data_kind": "multi_depth_volume", "data": payload, "scientific_rules": {"synthetic_data": False, "interpolation": False}}

        if canonical in self.DERIVED:
            u = self.volume_engine.build_volume(ocean=selected, latitude_min=bbox["latitude_min"], latitude_max=bbox["latitude_max"], longitude_min=bbox["longitude_min"], longitude_max=bbox["longitude_max"], time_utc=time_utc, variable="UVEL", depths_m=depth_values)
            v = self.volume_engine.build_volume(ocean=selected, latitude_min=bbox["latitude_min"], latitude_max=bbox["latitude_max"], longitude_min=bbox["longitude_min"], longitude_max=bbox["longitude_max"], time_utc=time_utc, variable="VVEL", depths_m=depth_values)
            direction = canonical == "current_direction"
            payload = deepcopy(u)
            payload["variable"] = {"name": definition["name"], "output_name": definition["short_name"], "units": definition["unit"], "dimensions": "depth,latitude,longitude", "depth_dependent": True}
            payload["request"]["variable"] = canonical
            payload["levels"] = self._derive_levels(u, v, direction)
            payload["source"] = {"provider": "INCOIS", "dataset": "RSMC HYCOM", "fields": ["UVEL", "VVEL"], "derivation": definition["source"].get("formula")}
            return {"available": True, "selection": selection, "variable": definition, "data_kind": "derived_multi_depth_volume", "data": payload, "scientific_rules": {"synthetic_data": False, "interpolation": False, "derived_from_real_source_fields": True}}

        raise NotImplementedError(f"Variable '{canonical}' does not have a connected real-data router yet.")


__all__ = ["OceanDataEngine", "DEFAULT_RADIUS_KM", "MAX_RADIUS_KM"]
