from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Sequence

import numpy as np

from .ocean_geometry import OceanGeometryEngine
from .ocean_slice import OceanSliceEngine, VARIABLES


@dataclass(frozen=True)
class OceanVolumeLevel:
    requested_depth_m: float
    actual_depth_m: float | None
    units: str
    latitudes: list[float]
    longitudes: list[float]
    values: list[list[float | None]]
    missing_mask: list[list[bool]]
    water_mask: list[list[bool]]
    valid_value_count: int
    source: str
    datasets: list[str]
    source_urls: list[str]
    chunk_files: list[str]
    provenance_paths: list[str]
    actual_time_utc: str


class OceanVolumeEngine:
    """
    Assemble a real multi-depth ocean volume from existing scientific source
    slices without interpolating the source values.

    Phase 2 responsibilities:

        * exact selected-ocean boundary from OceanGeometryEngine
        * real HYCOM depth levels/slices
        * water/land masking from the selected ocean geometry
        * explicit missing-value masks
        * exact source-time enforcement inherited from OceanSliceEngine
        * deterministic source-grid reduction when a global request is large

    The engine deliberately does not invent values for unsupported variables,
    unavailable source cells, or unavailable source times.
    """

    DEFAULT_DEPTHS_M: tuple[float, ...] = (
        0.0,
        10.0,
        50.0,
        100.0,
        250.0,
        500.0,
    )

    MAX_DEPTH_LEVELS = 24
    MAX_GRID_POINTS = 1_000_000

    def __init__(
        self,
        slice_engine: OceanSliceEngine | None = None,
        geometry_engine: OceanGeometryEngine | None = None,
    ) -> None:
        self.slice_engine = slice_engine or OceanSliceEngine()
        self.geometry_engine = geometry_engine or OceanGeometryEngine()

    @staticmethod
    def _normalize_depths(depths_m: Sequence[float] | None) -> list[float]:
        if depths_m is None:
            return list(OceanVolumeEngine.DEFAULT_DEPTHS_M)

        normalized = sorted({round(float(depth), 6) for depth in depths_m})

        if not normalized:
            raise ValueError("depths_m must contain at least one depth.")

        if len(normalized) > OceanVolumeEngine.MAX_DEPTH_LEVELS:
            raise ValueError(
                f"At most {OceanVolumeEngine.MAX_DEPTH_LEVELS} depth levels may be requested."
            )

        if normalized[0] < 0.0:
            raise ValueError("depths_m cannot contain negative values.")

        return normalized

    @staticmethod
    def _normalize_bbox(
        latitude_min: float,
        latitude_max: float,
        longitude_min: float,
        longitude_max: float,
    ) -> tuple[float, float, float, float]:
        latitude_min = float(latitude_min)
        latitude_max = float(latitude_max)
        longitude_min = float(longitude_min)
        longitude_max = float(longitude_max)

        if not -90.0 <= latitude_min <= 90.0:
            raise ValueError("latitude_min must be between -90 and 90.")

        if not -90.0 <= latitude_max <= 90.0:
            raise ValueError("latitude_max must be between -90 and 90.")

        if latitude_min > latitude_max:
            raise ValueError("latitude_min cannot be greater than latitude_max.")

        if not -180.0 <= longitude_min <= 180.0:
            raise ValueError("longitude_min must be between -180 and 180.")

        if not -180.0 <= longitude_max <= 180.0:
            raise ValueError("longitude_max must be between -180 and 180.")

        if longitude_min > longitude_max:
            raise ValueError(
                "longitude_min cannot be greater than longitude_max in Phase 2. "
                "Use an antimeridian-safe bbox split at the API layer."
            )

        return latitude_min, latitude_max, longitude_min, longitude_max

    @staticmethod
    def _finite_grid(values: Any) -> list[list[float | None]]:
        array = np.asarray(values, dtype=np.float64)

        result: list[list[float | None]] = []

        for row in array:
            result.append(
                [
                    float(value) if np.isfinite(value) else None
                    for value in row
                ]
            )

        return result

    @staticmethod
    def _boolean_grid(values: Any) -> list[list[bool]]:
        array = np.asarray(values, dtype=bool)
        return [[bool(value) for value in row] for row in array]

    @staticmethod
    def _water_mask(
        latitudes: Sequence[float],
        longitudes: Sequence[float],
        geometry: dict[str, Any],
    ) -> np.ndarray:
        """
        Mark source-grid cell centers that fall inside the selected real ocean
        polygon/multipolygon.

        This is a geometry classification operation, not data interpolation.
        "covers" is used so boundary points are retained as water when the
        center lies exactly on a source-derived boundary.
        """
        try:
            from shapely.geometry import Point, shape  # type: ignore[reportMissingModuleSource]
        except ImportError as exc:
            raise RuntimeError(
                "shapely is required for the Phase 2 ocean water mask."
            ) from exc

        source_geometry = shape(geometry)

        mask = np.zeros(
            (len(latitudes), len(longitudes)),
            dtype=bool,
        )

        for row_index, latitude in enumerate(latitudes):
            for column_index, longitude in enumerate(longitudes):
                mask[row_index, column_index] = bool(
                    source_geometry.covers(
                        Point(float(longitude), float(latitude))
                    )
                )

        return mask

    @staticmethod
    def _reduction_indices(
        latitude_count: int,
        longitude_count: int,
        max_points: int,
    ) -> tuple[list[int], list[int]]:
        """
        Select regularly spaced existing source-grid indices.

        No interpolation is performed. The returned indices always point to
        real source-grid rows and columns.

        The selection tries to preserve the original geographic aspect ratio
        while keeping the resulting grid within max_points.
        """
        if latitude_count <= 0 or longitude_count <= 0:
            raise ValueError("Source-grid dimensions must be positive.")

        point_count = latitude_count * longitude_count

        if point_count <= max_points:
            return (
                list(range(latitude_count)),
                list(range(longitude_count)),
            )

        latitude_step = 1
        longitude_step = 1

        while (
            int(np.ceil(latitude_count / latitude_step))
            * int(np.ceil(longitude_count / longitude_step))
            > max_points
        ):
            current_lat_count = int(np.ceil(latitude_count / latitude_step))
            current_lon_count = int(np.ceil(longitude_count / longitude_step))

            next_lat_count = int(
                np.ceil(latitude_count / (latitude_step + 1))
            )
            next_lon_count = int(
                np.ceil(longitude_count / (longitude_step + 1))
            )

            current_lat_reduction = current_lat_count - next_lat_count
            current_lon_reduction = current_lon_count - next_lon_count

            if (
                current_lat_reduction / max(current_lat_count, 1)
                >= current_lon_reduction / max(current_lon_count, 1)
            ):
                latitude_step += 1
            else:
                longitude_step += 1

        latitude_indices = list(range(0, latitude_count, latitude_step))
        longitude_indices = list(range(0, longitude_count, longitude_step))

        if latitude_indices[-1] != latitude_count - 1:
            latitude_indices.append(latitude_count - 1)

        if longitude_indices[-1] != longitude_count - 1:
            longitude_indices.append(longitude_count - 1)

        while len(latitude_indices) * len(longitude_indices) > max_points:
            if len(latitude_indices) >= len(longitude_indices):
                latitude_indices = latitude_indices[::2]
            else:
                longitude_indices = longitude_indices[::2]

        return latitude_indices, longitude_indices

    def build_volume(
        self,
        *,
        ocean: str,
        latitude_min: float,
        latitude_max: float,
        longitude_min: float,
        longitude_max: float,
        time_utc: str,
        variable: str = "TEMP",
        depths_m: Sequence[float] | None = None,
    ) -> dict[str, Any]:
        """
        Build a selected-ocean multi-depth volume from real HYCOM slices.

        The caller supplies a geographic bbox. The selected ocean boundary is
        still returned in full, and every returned grid has a water_mask so the
        frontend can render only cells belonging to the selected ocean.

        Large source grids are reduced by selecting existing source-grid
        indices only. No interpolation or synthetic values are used.
        """
        (
            latitude_min,
            latitude_max,
            longitude_min,
            longitude_max,
        ) = self._normalize_bbox(
            latitude_min,
            latitude_max,
            longitude_min,
            longitude_max,
        )

        normalized_depths = self._normalize_depths(depths_m)

        variable_code = str(variable).strip().upper()

        if variable_code not in VARIABLES:
            raise ValueError(
                "Unsupported HYCOM variable. Supported variables are: "
                + ", ".join(VARIABLES.keys())
                + "."
            )

        boundary = self.geometry_engine.boundary(ocean)

        if not boundary.available or boundary.geometry is None:
            raise LookupError(
                f"No real ocean boundary geometry is available for {boundary.ocean_name}."
            )

        levels: list[dict[str, Any]] = []
        common_latitudes: list[float] | None = None
        common_longitudes: list[float] | None = None

        total_points = None
        source_grid_reduced = False
        original_point_count: int | None = None

        for requested_depth in normalized_depths:
            slice_result = self.slice_engine.query_dict(
                latitude_min=latitude_min,
                latitude_max=latitude_max,
                longitude_min=longitude_min,
                longitude_max=longitude_max,
                depth_m=requested_depth,
                time_utc=time_utc,
                variable=variable_code,
            )

            grid = slice_result.get("grid", {})

            source_latitudes = [
                float(value)
                for value in grid.get("latitudes", [])
            ]

            source_longitudes = [
                float(value)
                for value in grid.get("longitudes", [])
            ]

            if not source_latitudes or not source_longitudes:
                raise LookupError(
                    f"No source grid was returned for depth {requested_depth} m."
                )

            lat_indices = [
                index
                for index, value in enumerate(source_latitudes)
                if latitude_min <= value <= latitude_max
            ]

            lon_indices = [
                index
                for index, value in enumerate(source_longitudes)
                if longitude_min <= value <= longitude_max
            ]

            if not lat_indices or not lon_indices:
                raise LookupError(
                    "No source-grid cells fall inside the requested bounding box."
                )

            latitudes = [
                source_latitudes[index]
                for index in lat_indices
            ]

            longitudes = [
                source_longitudes[index]
                for index in lon_indices
            ]

            values = np.asarray(
                grid.get("values", []),
                dtype=np.float64,
            )

            missing = np.asarray(
                grid.get("missing_mask", []),
                dtype=bool,
            )

            values = values[np.ix_(lat_indices, lon_indices)]
            missing = missing[np.ix_(lat_indices, lon_indices)]

            point_count_before_reduction = len(latitudes) * len(longitudes)

            if original_point_count is None:
                original_point_count = point_count_before_reduction

            if point_count_before_reduction > self.MAX_GRID_POINTS:
                reduced_lat_indices, reduced_lon_indices = (
                    self._reduction_indices(
                        latitude_count=len(latitudes),
                        longitude_count=len(longitudes),
                        max_points=self.MAX_GRID_POINTS,
                    )
                )

                latitudes = [
                    latitudes[index]
                    for index in reduced_lat_indices
                ]

                longitudes = [
                    longitudes[index]
                    for index in reduced_lon_indices
                ]

                values = values[
                    np.ix_(reduced_lat_indices, reduced_lon_indices)
                ]

                missing = missing[
                    np.ix_(reduced_lat_indices, reduced_lon_indices)
                ]

                source_grid_reduced = True

            point_count = len(latitudes) * len(longitudes)

            total_points = (
                point_count
                if total_points is None
                else max(total_points, point_count)
            )

            if point_count > self.MAX_GRID_POINTS:
                raise RuntimeError(
                    "Source-grid reduction failed to satisfy the Phase 2 "
                    f"limit of {self.MAX_GRID_POINTS} cells."
                )

            water_mask = self._water_mask(
                latitudes=latitudes,
                longitudes=longitudes,
                geometry=boundary.geometry,
            )

            if values.shape != water_mask.shape:
                raise RuntimeError(
                    "HYCOM source-grid shape does not match the generated "
                    "ocean water mask."
                )

            values_for_output = values.copy()
            values_for_output[~water_mask] = np.nan

            missing_for_output = missing.copy()
            missing_for_output[~water_mask] = True

            valid_value_count = int(
                np.count_nonzero(
                    water_mask
                    & ~missing_for_output
                    & np.isfinite(values_for_output)
                )
            )

            if valid_value_count == 0:
                raise LookupError(
                    f"No valid real {variable_code} source values were returned "
                    f"inside the selected {boundary.ocean_name} boundary at "
                    f"depth {requested_depth} m."
                )

            if common_latitudes is None:
                common_latitudes = latitudes
                common_longitudes = longitudes
            elif (
                common_latitudes != latitudes
                or common_longitudes != longitudes
            ):
                raise RuntimeError(
                    "HYCOM depth slices returned different source grids. "
                    "Phase 2 requires a common geographic grid for the "
                    "3D volume."
                )

            levels.append(
                {
                    "requested_depth_m": float(requested_depth),
                    "actual_depth_m": slice_result.get(
                        "actual",
                        {},
                    ).get("depth_m"),
                    "units": slice_result.get(
                        "variable",
                        {},
                    ).get("units"),
                    "latitudes": latitudes,
                    "longitudes": longitudes,
                    "values": self._finite_grid(values_for_output),
                    "missing_mask": self._boolean_grid(missing_for_output),
                    "water_mask": self._boolean_grid(water_mask),
                    "valid_value_count": valid_value_count,
                    "actual_time_utc": slice_result.get(
                        "actual",
                        {},
                    ).get("time_utc"),
                    "source": slice_result.get("source", {}),
                    "provenance": slice_result.get("provenance", {}),
                    "chunk_files": slice_result.get(
                        "source",
                        {},
                    ).get("chunk_files", []),
                    "datasets": slice_result.get(
                        "source",
                        {},
                    ).get("datasets", []),
                    "source_urls": slice_result.get(
                        "source",
                        {},
                    ).get("source_urls", []),
                    "provenance_paths": slice_result.get(
                        "source",
                        {},
                    ).get("provenance_paths", []),
                }
            )

        return {
            "available": True,
            "ocean": {
                "name": boundary.ocean_name,
                "source_region": boundary.source_region,
                "boundary": boundary.geometry,
                "bounding_box": boundary.bounding_box,
            },
            "request": {
                "latitude_min": latitude_min,
                "latitude_max": latitude_max,
                "longitude_min": longitude_min,
                "longitude_max": longitude_max,
                "time_utc": time_utc,
                "variable": variable_code,
                "depths_m": normalized_depths,
            },
            "variable": {
                "name": variable_code,
                "output_name": VARIABLES[variable_code].output_name,
                "units": VARIABLES[variable_code].units,
                "dimensions": VARIABLES[variable_code].dimensions,
                "depth_dependent": VARIABLES[variable_code].depth_dependent,
            },
            "grid": {
                "latitude_count": len(common_latitudes or []),
                "longitude_count": len(common_longitudes or []),
                "point_count": total_points or 0,
                "original_point_count": original_point_count or 0,
                "source_grid_reduced": source_grid_reduced,
                "latitudes": common_latitudes or [],
                "longitudes": common_longitudes or [],
            },
            "levels": levels,
            "scientific_rules": {
                "synthetic_data": False,
                "interpolation": False,
                "source_grid_values_only": True,
                "source_grid_reduction": (
                    "regular existing source-grid indices only"
                    if source_grid_reduced
                    else "none"
                ),
                "water_mask_from_real_ocean_geometry": True,
                "depth_selection": "nearest available real HYCOM depth level",
            },
            "source": {
                "provider": "INCOIS",
                "dataset": "RSMC HYCOM",
                "description": (
                    "Real HYCOM source-grid depth slices assembled into "
                    "a multi-depth volume."
                ),
            },
            "generated_at_utc": (
                datetime.now(timezone.utc)
                .replace(microsecond=0)
                .isoformat()
                .replace("+00:00", "Z")
            ),
        }