from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query,Response
from fastapi.middleware.cors import CORSMiddleware
from .ocean_tiles import OceanTileEngine
from .argo_live_manager import ArgoLiveManager
from .argo_query import ArgoQueryEngine
from .ocean_3d_query import Ocean3DQueryEngine
from .ocean_slice import OceanSliceEngine
from .ocean_regions import OceanRegionEngine
from .ocean_geometry import OceanGeometryEngine
from .ocean_volume import OceanVolumeEngine
from .ocean_bathymetry import OceanBathymetryEngine
from .ocean_variables import get_variable_catalog, get_variable_definition, normalize_variable_name
from .provider_registry import catalog_with_providers, provider_for
from .ocean_sensors import OceanSensorEngine

try:
    from .ocean_time import OceanTimeEngine  # type: ignore[reportMissingImports]
except ImportError:  # pragma: no cover - fallback for missing optional module
    class OceanTimeEngine:  # type: ignore[no-redef]
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            raise RuntimeError(
                "OceanTimeEngine is unavailable because the optional source module is missing."
            )

from .ocean_context import OceanContextEngine
from .ocean_data import OceanDataEngine

from .navigation_models import (
    NavigationRequest,
    NavigationResult,
)
from .navigation_astar import (
    NavigationRouteEngine,
)

from .schemas import (
    ArgoProfileDiscoveryResponse,
    ArgoProfileSeries,
    HealthResponse,
    OceanPointResponse,
    RootResponse,
)


# =============================================================================
# OCEANSIGHT-V
# SCIENTIFIC FASTAPI
#
# Sources:
#
#   Ocean state  -> INCOIS HYCOM
#   Observations -> INCOIS Indian Argo
#   Bathymetry   -> GEBCO 2026
#   Ocean region -> RECCAP2 Ocean regional masks
#
# API:
#
#   /
#   /api/v1/health
#   /api/v1/hycom/times
#   /api/v1/ocean/regions
#   /api/v1/ocean/identify
#   /api/v1/ocean/point
#   /api/v1/ocean/slice
#   /api/v1/ocean/time-window
#   /api/v1/ocean/time-range
#   /api/v1/argo/profiles
#   /api/v1/argo/profile
#   /api/v1/ocean/sensors
#   /api/v1/ocean/sensors
#   /api/v1/ocean/sensor
#   /api/v1/ocean/sensor-types
#   /api/v1/navigation/route
#
# Scientific rules:
#
#   synthetic data = false
#   interpolation  = false
#   Argo PRES      = dbar
#   Argo PRES is never silently converted to depth.
#
# Navigation:
#
#   Navigation uses the verified OceanSight 4D A* engine.
#   HYCOM environmental timestamps come from real INCOIS source TIME values.
#
# Ocean-region identification:
#
#   Coordinates are resolved against a real source regional mask.
#   No synthetic polygons or latitude/longitude heuristics are used.
# =============================================================================


app = FastAPI(
    title="OceanSight-V Scientific API",
    version="1.0.0",
    description=(
        "Scientific ocean data API backed by "
        "INCOIS HYCOM, INCOIS Argo, GEBCO 2026, "
        "RECCAP2 Ocean regional masks, "
        "and the OceanSight-V 4D navigation engine. "
        "Real source observations can be acquired live "
        "when they are not already available locally."
    ),
)


# =============================================================================
# CORS
# =============================================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# SCIENTIFIC ENGINES
# =============================================================================

engine = Ocean3DQueryEngine()

slice_engine = OceanSliceEngine()

ocean_tile_engine = OceanTileEngine(
    slice_engine=slice_engine,
)

argo_engine = ArgoQueryEngine()

argo_live_manager = ArgoLiveManager()

ocean_sensor_engine = OceanSensorEngine()

_ocean_context_engine: OceanContextEngine | None = None

def get_ocean_context_engine() -> OceanContextEngine:
    """Lazily create the unified Ocean/Block scientific context engine."""
    global _ocean_context_engine
    if _ocean_context_engine is None:
        _ocean_context_engine = OceanContextEngine(
            region_engine=get_ocean_region_engine(),
            geometry_engine=get_ocean_geometry_engine(),
            time_engine=get_ocean_time_engine(),
            sensor_engine=ocean_sensor_engine,
        )
    return _ocean_context_engine

_ocean_time_engine: OceanTimeEngine | None = None


def get_ocean_time_engine() -> OceanTimeEngine:
    """Lazily create the source-timestamp time engine."""
    global _ocean_time_engine
    if _ocean_time_engine is None:
        _ocean_time_engine = OceanTimeEngine()
    return _ocean_time_engine


# =============================================================================
# OCEAN REGION ENGINE
# =============================================================================
#
# IMPORTANT:
#
# Do NOT initialize the real regional-mask dataset at module import time.
#
# That keeps FastAPI startup behavior tolerant if the dataset has not yet
# been placed in backend/data/ocean_regions/.
#
# The engine is created only when an ocean-region endpoint is actually called.
# =============================================================================

_ocean_region_engine: OceanRegionEngine | None = None


def get_ocean_region_engine() -> OceanRegionEngine:
    """
    Lazily create the real ocean-region resolver.

    The regional dataset is opened only when required.
    """

    global _ocean_region_engine

    if _ocean_region_engine is None:
        _ocean_region_engine = OceanRegionEngine()

    return _ocean_region_engine


# =============================================================================
# NAVIGATION ENGINE
# =============================================================================
#
# IMPORTANT:
#
# NavigationRouteEngine performs live HYCOM time discovery when it is
# initialized.
#
# Therefore it is intentionally created lazily on the first navigation
# request rather than at FastAPI import time.
# =============================================================================

_navigation_engine: NavigationRouteEngine | None = None


def get_navigation_engine() -> NavigationRouteEngine:
    """
    Lazily create the verified 4D navigation engine.

    Existing scientific API startup behavior remains unchanged because
    INCOIS navigation discovery is not performed merely by importing
    app.api.
    """

    global _navigation_engine

    if _navigation_engine is None:

        _navigation_engine = (
            NavigationRouteEngine()
        )

    return _navigation_engine


# =============================================================================
# PATHS
# =============================================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parent.parent
)

HYCOM_TIME_CATALOG = (
    PROJECT_ROOT
    / "processed"
    / "hycom_catalog"
    / "hycom_times.json"
)


# =============================================================================
# ARGO CONSTANTS
# =============================================================================

ARGO_SOURCE = "INCOIS ERDDAP"

ARGO_DATASET = "Indian_ARGO_Floats"

ARGO_SOURCE_URL = (
    "https://erddap.incois.gov.in/"
    "erddap/tabledap/"
    "Indian_ARGO_Floats.csv"
)


# =============================================================================
# TIME VALIDATION
# =============================================================================

def validate_time_utc(
    time_utc: str,
) -> str:
    """
    Validate and normalize an ISO-8601 UTC timestamp.

    Accepted examples:

        2026-09-10T06:00:00Z
        2026-09-10T06:00:00+00:00

    Returned form:

        2026-09-10T06:00:00Z
    """

    value = str(
        time_utc
    ).strip()

    if not value:

        raise ValueError(
            "time_utc cannot be empty."
        )

    try:

        normalized = value

        if normalized.endswith(
            "Z"
        ):

            normalized = (
                normalized[:-1]
                + "+00:00"
            )

        parsed = datetime.fromisoformat(
            normalized
        )

    except ValueError as exc:

        raise ValueError(
            "time_utc must be a valid ISO-8601 "
            "UTC timestamp, for example "
            "2026-09-10T06:00:00Z."
        ) from exc

    if parsed.tzinfo is None:

        raise ValueError(
            "time_utc must include an explicit timezone."
        )

    parsed_utc = parsed.astimezone(
        timezone.utc
    )

    return (
        parsed_utc
        .replace(
            microsecond=0
        )
        .isoformat()
        .replace(
            "+00:00",
            "Z",
        )
    )


# =============================================================================
# ROOT
# =============================================================================

@app.get(
    "/",
    response_model=RootResponse,
)
def root() -> dict[str, Any]:

    return {
        "name": "OceanSight-V",

        "service": (
            "Scientific Ocean Data API"
        ),

        "status": "running",

        "scientific_engine": {
            "status": "ready",
            "synthetic_data": False,
            "interpolation": False,
        },

        "sources": {
            "ocean_state": {
                "provider": "INCOIS",
                "dataset": "RSMC HYCOM",
            },

            "observations": {
                "provider": "INCOIS",
                "dataset": "Indian_ARGO_Floats",
            },

            "bathymetry": {
                "provider": "GEBCO",
                "dataset": "GEBCO_2026",
            },

            "ocean_regions": {
                "provider": "RECCAP2 Ocean",
                "dataset": (
                    "RECCAP2 regional ocean masks"
                ),
            },
        },

        "scientific_units": {
            "HYCOM_depth": "m",
            "ARGO_pressure": "dbar",
            "ARGO_temperature": (
                "degree_Celsius"
            ),
            "ARGO_salinity": "PSU",
            "GEBCO_elevation": "m",
        },

        "scientific_rules": {
            "argo_pressure_converted_to_depth": False,
            "synthetic_data": False,
            "interpolation": False,
            "ocean_region_heuristics": False,
        },
    }


# =============================================================================
# HEALTH
# =============================================================================

@app.get(
    "/api/v1/health",
    response_model=HealthResponse,
)
def health() -> dict[str, Any]:

    return {
        "status": "ok",

        "scientific_engine": "ready",

        "synthetic_data": False,

        "interpolation": False,

        "components": {
            "hycom": "enabled",
            "argo": "enabled",
            "gebco": "enabled",

            "ocean_region_resolver": (
                "enabled"
            ),

            "live_hycom_acquisition": (
                "enabled"
            ),

            "live_argo_acquisition": (
                "enabled"
            ),

            "live_gebco_acquisition": (
                "enabled"
            ),

            "navigation_4d_astar": (
                "enabled"
            ),
            "ocean_time_engine": (
                "enabled"
            ),
        },

        "scientific_units": {
            "hycom_depth": "m",
            "argo_pressure": "dbar",
            "gebco_elevation": "m",
        },
    }


# =============================================================================
# OCEAN REGION LIST
# =============================================================================

@app.get(
    "/api/v1/ocean/regions",
)
def ocean_regions() -> dict[str, Any]:
    """
    Return the five supported real ocean-region masks.

    These names are sourced from the real regional-mask engine and are
    intended for the Earth-screen ocean selector.
    """

    try:

        resolver = (
            get_ocean_region_engine()
        )

        return {
            "available": True,

            "oceans": resolver.list_oceans(),

            "source": {
                "provider": (
                    "RECCAP2 Ocean"
                ),
                "dataset": (
                    "RECCAP2 regional ocean masks"
                ),
            },

            "scientific_rules": {
                "synthetic_data": False,
                "interpolation": False,
            },
        }

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Ocean-region resolver unavailable: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Ocean-region listing failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# OCEAN REGION IDENTIFICATION
# =============================================================================

@app.get(
    "/api/v1/ocean/identify",
)
def ocean_identify(
    latitude: float = Query(
        ...,
        ge=-90.0,
        le=90.0,
        description=(
            "Requested latitude in degrees."
        ),
    ),

    longitude: float = Query(
        ...,
        ge=-180.0,
        le=180.0,
        description=(
            "Requested longitude in degrees."
        ),
    ),
) -> dict[str, Any]:
    """
    Resolve a geographic coordinate against the real ocean-region mask.

    Important:

        Clicking Earth does NOT call this endpoint automatically.

        SEARCH is the action that should call this endpoint.

    The endpoint never invents an ocean name.
    """

    try:

        resolver = (
            get_ocean_region_engine()
        )

        result = resolver.identify_dict(
            latitude=float(
                latitude
            ),
            longitude=float(
                longitude
            ),
        )

        result["api"] = {
            "version": "1.0",

            "endpoint": (
                "/api/v1/ocean/identify"
            ),

            "synthetic_data": False,

            "interpolation": False,
        }

        return result

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Ocean-region identification failed: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Ocean-region identification failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# REAL OCEAN BOUNDARY GEOMETRY
# =============================================================================

_ocean_geometry_engine: OceanGeometryEngine | None = None
_ocean_volume_engine: OceanVolumeEngine | None = None


def get_ocean_geometry_engine() -> OceanGeometryEngine:
    """
    Lazily create the exact source-mask ocean geometry engine.
    """

    global _ocean_geometry_engine

    if _ocean_geometry_engine is None:
        _ocean_geometry_engine = OceanGeometryEngine()

    return _ocean_geometry_engine


def get_ocean_volume_engine() -> OceanVolumeEngine:
    """Lazily create the Phase 2 real multi-depth ocean-volume engine."""

    global _ocean_volume_engine

    if _ocean_volume_engine is None:
        _ocean_volume_engine = OceanVolumeEngine(
            slice_engine=slice_engine,
            geometry_engine=get_ocean_geometry_engine(),
        )

    return _ocean_volume_engine


_ocean_bathymetry_engine: OceanBathymetryEngine | None = None


def get_ocean_bathymetry_engine() -> OceanBathymetryEngine:
    """Lazily create the real GEBCO bathymetry engine."""

    global _ocean_bathymetry_engine

    if _ocean_bathymetry_engine is None:
        _ocean_bathymetry_engine = OceanBathymetryEngine(
            geometry_engine=get_ocean_geometry_engine(),
        )

    return _ocean_bathymetry_engine


_ocean_data_engine: OceanDataEngine | None = None


def get_ocean_data_engine() -> OceanDataEngine:
    """Lazily create the unified scientific data router."""

    global _ocean_data_engine

    if _ocean_data_engine is None:
        _ocean_data_engine = OceanDataEngine(
            volume_engine=get_ocean_volume_engine(),
            bathymetry_engine=get_ocean_bathymetry_engine(),
            geometry_engine=get_ocean_geometry_engine(),
        )

    return _ocean_data_engine


# =============================================================================
# REAL GEBCO BATHYMETRY SURFACE
# =============================================================================

@app.get(
    "/api/v1/ocean/bathymetry",
)
def ocean_bathymetry(
    ocean: str = Query(
        ...,
        min_length=1,
        description="Selected real ocean name.",
    ),
    latitude_min: float = Query(..., ge=-90.0, le=90.0),
    latitude_max: float = Query(..., ge=-90.0, le=90.0),
    longitude_min: float = Query(..., ge=-180.0, le=180.0),
    longitude_max: float = Query(..., ge=-180.0, le=180.0),
) -> dict[str, Any]:
    """
    Return a real GEBCO numerical bathymetry surface masked to the selected
    RECCAP2 ocean geometry.

    This endpoint is intended to feed the 3D ocean-floor renderer. It returns
    the source grid, elevation, missing-data mask, water mask and provenance.
    No interpolation or synthetic bathymetry is performed.
    """

    try:
        result = get_ocean_bathymetry_engine().build_surface(
            ocean=ocean,
            latitude_min=float(latitude_min),
            latitude_max=float(latitude_max),
            longitude_min=float(longitude_min),
            longitude_max=float(longitude_max),
        )
        result["api"] = {
            "version": "3.0",
            "endpoint": "/api/v1/ocean/bathymetry",
            "synthetic_data": False,
            "interpolation": False,
        }
        return result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Bathymetry scientific engine unavailable: {exc}",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Bathymetry query failed: {exc}",
        ) from exc


@app.get(
    "/api/v1/ocean/boundary",
)
def ocean_boundary(
    ocean: str = Query(
        ...,
        min_length=1,
        description=(
            "Ocean name. Examples: Indian Ocean, Atlantic Ocean, "
            "Pacific Ocean, Southern Ocean, Arctic Ocean."
        ),
    ),
) -> dict[str, Any]:
    """
    Return the exact polygonal boundary represented by the real RECCAP2
    regional mask for the requested ocean.

    The returned geometry is derived from source mask cell edges. No
    synthetic polygon, coordinate heuristic, or interpolation is used.
    """

    try:

        resolver = get_ocean_geometry_engine()

        result = resolver.boundary_dict(
            ocean=ocean,
        )

        result["api"] = {
            "version": "1.1",
            "endpoint": "/api/v1/ocean/boundary",
            "synthetic_data": False,
            "interpolation": False,
        }

        return result

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Ocean-boundary geometry unavailable: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Ocean-boundary geometry generation failed: "
                f"{exc}"
            ),
        ) from exc



# =============================================================================
# REAL MULTI-DEPTH OCEAN VOLUME
# =============================================================================


@app.get(
    "/api/v1/ocean/volume",
)
def ocean_volume(
    ocean: str = Query(
        ...,
        min_length=1,
        description="Selected real ocean name.",
    ),
    latitude_min: float = Query(..., ge=-90.0, le=90.0),
    latitude_max: float = Query(..., ge=-90.0, le=90.0),
    longitude_min: float = Query(..., ge=-180.0, le=180.0),
    longitude_max: float = Query(..., ge=-180.0, le=180.0),
    time_utc: str = Query(
        ...,
        description="Exact INCOIS HYCOM source time in ISO-8601 UTC form.",
    ),
    variable: str = Query(
        default="TEMP",
        description="HYCOM variable: TEMP, SALN, UVEL, VVEL, or SSH.",
    ),
    depth_m: str | None = Query(
        default=None,
        description="Comma-separated real/requested depth levels in meters. Example: 0,10,50,100,250,500.",
    ),
) -> dict[str, Any]:
    """
    Return a real multi-depth selected-ocean volume.

    The API combines the exact RECCAP2-derived ocean geometry with real INCOIS
    HYCOM source-grid slices. Values outside the selected ocean polygon are
    explicitly masked instead of being rendered as ocean data.
    """

    try:
        requested_depths = None

        if depth_m is not None:
            text = str(depth_m).strip()
            if text:
                try:
                    requested_depths = [
                        float(part.strip())
                        for part in text.split(",")
                        if part.strip()
                    ]
                except ValueError as exc:
                    raise ValueError(
                        "depth_m must be a comma-separated list of numeric meters."
                    ) from exc

        result = get_ocean_volume_engine().build_volume(
            ocean=ocean,
            latitude_min=float(latitude_min),
            latitude_max=float(latitude_max),
            longitude_min=float(longitude_min),
            longitude_max=float(longitude_max),
            time_utc=validate_time_utc(time_utc),
            variable=variable,
            depths_m=requested_depths,
        )

        result["api"] = {
            "version": "2.0",
            "endpoint": "/api/v1/ocean/volume",
            "synthetic_data": False,
            "interpolation": False,
        }

        return result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Ocean-volume scientific engine unavailable: {exc}",
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ocean-volume query failed: {exc}",
        ) from exc


# =============================================================================
# UNIFIED OCEAN SCIENTIFIC DATA
# =============================================================================


@app.get(
    "/api/v1/ocean/data",
)
def ocean_data(
    mode: str = Query(
        default="ocean",
        description="Data mode: 'ocean' for a selected basin or 'block' for a coordinate/radius region.",
    ),
    ocean: str | None = Query(
        default=None,
        description="Selected ocean name. For block mode the ocean can be resolved automatically from latitude/longitude.",
    ),
    latitude: float | None = Query(
        default=None,
        ge=-90.0,
        le=90.0,
        description="Selected latitude. Required for block mode and optionally resolves the ocean.",
    ),
    longitude: float | None = Query(
        default=None,
        ge=-180.0,
        le=180.0,
        description="Selected longitude. Required for block mode and optionally resolves the ocean.",
    ),
    radius_km: float = Query(
        default=50.0,
        gt=0.0,
        le=2000.0,
        description="Block radius in kilometers.",
    ),
    time_utc: str = Query(
        ...,
        description="Exact real INCOIS HYCOM source time for ocean-state variables.",
    ),
    variable: str = Query(
        default="temperature",
        description="Canonical variable id or connected source alias.",
    ),
    depths_m: str | None = Query(
        default=None,
        description="Optional comma-separated depth levels in meters.",
    ),
) -> dict[str, Any]:
    """
    Return unified real scientific data for Ocean Dashboard or Block Dashboard.

    Connected HYCOM variables are routed to the real multi-depth volume engine.
    Bathymetry is routed to real GEBCO. Current speed/direction are calculated
    only from real UVEL/VVEL fields. Unsupported variables return an explicit
    501 instead of fabricated scientific data.
    """

    try:
        requested_depths = None
        if depths_m is not None and str(depths_m).strip():
            try:
                requested_depths = [
                    float(part.strip())
                    for part in str(depths_m).split(",")
                    if part.strip()
                ]
            except ValueError as exc:
                raise ValueError(
                    "depths_m must be a comma-separated list of numeric meters."
                ) from exc

        result = get_ocean_data_engine().build_data(
            mode=mode,
            ocean=ocean,
            latitude=None if latitude is None else float(latitude),
            longitude=None if longitude is None else float(longitude),
            radius_km=float(radius_km),
            time_utc=validate_time_utc(time_utc),
            variable=variable,
            depths_m=requested_depths,
        )

        result["api"] = {
            "version": "1.0",
            "endpoint": "/api/v1/ocean/data",
            "synthetic_data": False,
            "interpolation": False,
        }
        return result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except NotImplementedError as exc:
        raise HTTPException(status_code=501, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Unified scientific-data engine unavailable: {exc}",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Unified scientific-data query failed: {exc}",
        ) from exc


# =============================================================================
# UNIFIED OCEAN VARIABLE CATALOG
# =============================================================================


@app.get(
    "/api/v1/ocean/variables",
)
def ocean_variables(
    variable: str | None = Query(
        default=None,
        description="Optional variable id or source code to look up.",
    ),
) -> dict[str, Any]:
    """
    Return the canonical OceanSight variable catalog.

    This endpoint is metadata-only: it never fabricates observations.  Each
    variable declares its real source, vertical availability, units, and
    whether the current backend can supply it from a connected scientific
    source.  Derived variables explicitly declare the source fields required
    to calculate them.
    """

    try:
        if variable is None:
            return {
                "available": True,
                "variables": catalog_with_providers(),
                "scientific_rules": {
                    "synthetic_data": False,
                    "interpolation": False,
                },
            }

        normalized = normalize_variable_name(variable)
        definition = get_variable_definition(normalized)

        return {
            "available": True,
            "variable": definition,
            "provider": provider_for(normalized),
            "scientific_rules": {
                "synthetic_data": False,
                "interpolation": False,
            },
        }

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc



# =============================================================================
# OCEAN TIME WINDOW / CALENDAR RANGE
# =============================================================================


@app.get(
    "/api/v1/ocean/time-window",
)
def ocean_time_window(
    reference_time_utc: str | None = Query(
        default=None,
        description=(
            "Reference time. When omitted, the backend uses the current UTC "
            "clock; only real source timestamps are returned."
        ),
    ),
    past_hours: float = Query(
        default=24.0,
        ge=0.0,
        le=720.0,
        description="Requested historical window in hours.",
    ),
    future_hours: float = Query(
        default=24.0,
        ge=0.0,
        le=720.0,
        description="Requested future/source-forecast window in hours.",
    ),
) -> dict[str, Any]:
    """
    Return the real HYCOM source timestamps inside a past/future window.

    The frontend time slider must use this endpoint rather than inventing
    six-hour or hourly timestamps. A future timestamp is classified as
    future only when that exact timestamp exists in the source catalog.
    """

    try:
        result = get_ocean_time_engine().window(
            reference_time_utc=reference_time_utc,
            past_hours=float(past_hours),
            future_hours=float(future_hours),
        )
        result["api"] = {
            "version": "1.0",
            "endpoint": "/api/v1/ocean/time-window",
            "synthetic_data": False,
            "interpolation": False,
        }
        return result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Ocean time engine unavailable: {exc}",
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ocean time-window query failed: {exc}",
        ) from exc


@app.get(
    "/api/v1/ocean/time-range",
)
def ocean_time_range(
    start_time_utc: str = Query(
        ...,
        description="Inclusive UTC range start.",
    ),
    end_time_utc: str = Query(
        ...,
        description="Inclusive UTC range end.",
    ),
) -> dict[str, Any]:
    """
    Return all real source timestamps inside an arbitrary calendar range.

    This endpoint is intended for the calendar UI. The user may select any
    supported year/month/day/time range; the response contains only source
    timestamps that actually exist in the catalog.
    """

    try:
        result = get_ocean_time_engine().range(
            start_time_utc=start_time_utc,
            end_time_utc=end_time_utc,
        )
        result["api"] = {
            "version": "1.0",
            "endpoint": "/api/v1/ocean/time-range",
            "synthetic_data": False,
            "interpolation": False,
        }
        return result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Ocean time engine unavailable: {exc}",
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ocean time-range query failed: {exc}",
        ) from exc


# =============================================================================
# OCEAN SENSOR / OBSERVATION PLATFORM DISCOVERY
# =============================================================================


@app.get(
    "/api/v1/ocean/sensors",
)
def ocean_sensors(
    latitude: float = Query(
        ...,
        ge=-90.0,
        le=90.0,
        description="Center latitude in degrees.",
    ),
    longitude: float = Query(
        ...,
        ge=-180.0,
        le=180.0,
        description="Center longitude in degrees.",
    ),
    radius_km: float = Query(
        default=100.0,
        gt=0.0,
        le=2000.0,
        description="Great-circle search radius in kilometers.",
    ),
    time_utc: str | None = Query(
        default=None,
        description="Optional exact Argo profile timestamp.",
    ),
    sensor_type: str | None = Query(
        default=None,
        description="Optional sensor type, currently argo_float.",
    ),
    limit: int = Query(
        default=100,
        ge=1,
        le=1000,
        description="Maximum number of observation platforms.",
    ),
) -> dict[str, Any]:
    """
    Discover real observation platforms around a coordinate.

    Phase 5 exposes only verified sensor sources. At present that means
    INCOIS Argo floats. Other sensor categories remain explicitly marked as
    unavailable until a real source is integrated.
    """

    try:
        normalized_time = None
        if time_utc is not None:
            normalized_time = validate_time_utc(time_utc)

        sensors = ocean_sensor_engine.discover_local(
            latitude=float(latitude),
            longitude=float(longitude),
            radius_km=float(radius_km),
            time_utc=normalized_time,
            limit=int(limit),
        )

        sensors = ocean_sensor_engine.filter_sensor_type(
            sensors,
            sensor_type=sensor_type,
        )[: int(limit)]

        return {
            "available": bool(sensors),
            "sensors": sensors,
            "sensor_count": len(sensors),
            "request": {
                "latitude": float(latitude),
                "longitude": float(longitude),
                "radius_km": float(radius_km),
                "time_utc": normalized_time,
                "sensor_type": sensor_type,
                "limit": int(limit),
            },
            "sensor_types": ocean_sensor_engine.sensor_types(),
            "source": {
                "verified_connected_sources": [
                    {
                        "sensor_type": "argo_float",
                        "provider": "INCOIS ERDDAP",
                        "dataset": "Indian_ARGO_Floats",
                    }
                ],
            },
            "scientific_rules": {
                "synthetic_data": False,
                "interpolation": False,
                "great_circle_radius_filter": True,
                "argo_pressure_unit": "dbar",
                "argo_pressure_is_depth": False,
                "argo_pressure_to_depth_conversion": False,
            },
        }

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ocean sensor discovery failed: {exc}",
        ) from exc


@app.get(
    "/api/v1/ocean/sensor",
)
def ocean_sensor(
    platform_number: str = Query(
        ...,
        min_length=1,
        description="Real Argo platform number.",
    ),
    cycle_number: int = Query(
        ...,
        ge=0,
        description="Real Argo cycle number.",
    ),
) -> dict[str, Any]:
    """Return complete real observations for a selected Argo platform/cycle."""

    try:
        result = argo_engine.get_profile_series(
            platform_number=str(platform_number).strip(),
            cycle_number=int(cycle_number),
        )

        if not result.get("available"):
            raise HTTPException(
                status_code=404,
                detail=(
                    "No real Argo sensor profile was found for "
                    f"platform {str(platform_number).strip()}, "
                    f"cycle {int(cycle_number)}."
                ),
            )

        result["api"] = {
            "version": "1.0",
            "endpoint": "/api/v1/ocean/sensor",
            "synthetic_data": False,
            "interpolation": False,
        }
        result["sensor"] = {
            "sensor_id": (
                f"argo:{str(platform_number).strip()}:{int(cycle_number)}"
            ),
            "sensor_type": "argo_float",
            "platform_number": str(platform_number).strip(),
            "cycle_number": int(cycle_number),
            "position_semantics": {
                "latitude_longitude": "real profile location from source",
                "pressure_unit": "dbar",
                "pressure_is_depth": False,
                "pressure_to_depth_conversion_performed": False,
            },
        }
        return result

    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ocean sensor profile query failed: {exc}",
        ) from exc


@app.get(
    "/api/v1/ocean/sensor-types",
)
def ocean_sensor_types() -> dict[str, Any]:
    """Return the verified and planned observation-platform categories."""
    return {
        "sensor_types": ocean_sensor_engine.sensor_types(),
        "scientific_rules": {
            "synthetic_data": False,
            "interpolation": False,
        },
    }


# =============================================================================
# HYCOM TIME-STEP DISCOVERY
# =============================================================================

@app.get(
    "/api/v1/hycom/times",
)
def hycom_times(
    time_utc: str | None = Query(
        default=None,
        description=(
            "Optional exact HYCOM source time "
            "to look up."
        ),
    ),
) -> dict[str, Any]:

    try:

        if not HYCOM_TIME_CATALOG.exists():

            raise HTTPException(
                status_code=503,
                detail=(
                    "HYCOM time catalog is not available. "
                    "Run: python -m app.hycom_times"
                ),
            )

        with HYCOM_TIME_CATALOG.open(
            "r",
            encoding="utf-8",
        ) as file:

            catalog = json.load(
                file
            )

        if not isinstance(
            catalog,
            dict,
        ):

            raise HTTPException(
                status_code=503,
                detail=(
                    "HYCOM time catalog has an invalid format."
                ),
            )

        # ---------------------------------------------------------------------
        # Complete catalog.
        # ---------------------------------------------------------------------

        if time_utc is None:

            return {
                "api": {
                    "version": "1.0",
                    "endpoint": (
                        "/api/v1/hycom/times"
                    ),
                    "synthetic_data": False,
                    "interpolation": False,
                },

                "source": {
                    "provider": "INCOIS",
                    "dataset": "RSMC HYCOM",
                    "service": "THREDDS OPeNDAP",
                },

                "catalog": catalog,
            }

        # ---------------------------------------------------------------------
        # Exact lookup.
        # ---------------------------------------------------------------------

        normalized_time_utc = (
            validate_time_utc(
                time_utc
            )
        )

        time_records = catalog.get(
            "times",
            [],
        )

        if not isinstance(
            time_records,
            list,
        ):

            raise HTTPException(
                status_code=503,
                detail=(
                    "HYCOM time catalog contains "
                    "an invalid times collection."
                ),
            )

        exact_match = None

        for record in time_records:

            if not isinstance(
                record,
                dict,
            ):

                continue

            if (
                record.get(
                    "time_utc"
                )
                == normalized_time_utc
            ):

                exact_match = record

                break

        if exact_match is None:

            return {
                "api": {
                    "version": "1.0",
                    "endpoint": (
                        "/api/v1/hycom/times"
                    ),
                    "synthetic_data": False,
                    "interpolation": False,
                },

                "source": {
                    "provider": "INCOIS",
                    "dataset": "RSMC HYCOM",
                    "service": "THREDDS OPeNDAP",
                },

                "available": False,

                "requested_time_utc": (
                    normalized_time_utc
                ),

                "actual_time_utc": None,

                "time": None,

                "scientific_rules": {
                    "exact_time_match": True,
                    "interpolation": False,
                    "synthetic_data": False,
                },
            }

        return {
            "api": {
                "version": "1.0",
                "endpoint": (
                    "/api/v1/hycom/times"
                ),
                "synthetic_data": False,
                "interpolation": False,
            },

            "source": {
                "provider": "INCOIS",
                "dataset": "RSMC HYCOM",
                "service": "THREDDS OPeNDAP",
            },

            "available": True,

            "requested_time_utc": (
                normalized_time_utc
            ),

            "actual_time_utc": (
                exact_match.get(
                    "time_utc"
                )
            ),

            "time": exact_match,

            "scientific_rules": {
                "exact_time_match": True,
                "interpolation": False,
                "synthetic_data": False,
            },
        }

    except HTTPException:

        raise

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except json.JSONDecodeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "HYCOM time catalog contains invalid JSON: "
                f"{exc}"
            ),
        ) from exc

    except OSError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Unable to read HYCOM time catalog: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "HYCOM time discovery API failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# UNIFIED OCEAN / BLOCK SCIENTIFIC CONTEXT
# =============================================================================


@app.get(
    "/api/v1/ocean/context",
)
def ocean_context(
    mode: str = Query(
        default="ocean",
        description="Context mode: 'ocean' for the selected basin or 'block' for a coordinate/radius region.",
    ),
    ocean: str | None = Query(
        default=None,
        description="Optional selected ocean. When coordinates are supplied, the real region mask validates the selection.",
    ),
    latitude: float | None = Query(
        default=None,
        ge=-90.0,
        le=90.0,
        description="Optional selected latitude. Required for block mode.",
    ),
    longitude: float | None = Query(
        default=None,
        ge=-180.0,
        le=180.0,
        description="Optional selected longitude. Required for block mode.",
    ),
    radius_km: float = Query(
        default=50.0,
        gt=0.0,
        le=2000.0,
        description="Block radius in kilometers. Used directly by block mode and as the sensor discovery radius.",
    ),
    variable: str = Query(
        default="TEMP",
        description="Canonical variable id or supported source alias.",
    ),
    reference_time_utc: str | None = Query(
        default=None,
        description="Optional reference time for the shared past/future time window.",
    ),
    past_hours: float = Query(
        default=24.0,
        ge=0.0,
        le=720.0,
        description="Historical time window in hours.",
    ),
    future_hours: float = Query(
        default=24.0,
        ge=0.0,
        le=720.0,
        description="Future/source-forecast window in hours.",
    ),
    include_sensors: bool = Query(
        default=True,
        description="Include locally indexed verified sensors around the selected coordinate when available.",
    ),
    sensor_limit: int = Query(
        default=100,
        ge=1,
        le=1000,
        description="Maximum number of sensors in the context response.",
    ),
) -> dict[str, Any]:
    """
    Return the shared scientific context used by Ocean Dashboard and Block Dashboard.

    The endpoint resolves the selected ocean from a real regional mask, returns
    the exact source-mask boundary, variable metadata, real source timestamps,
    and optional sensor discoveries. Large numerical volume/bathymetry payloads
    remain on their dedicated endpoints so the context response stays lightweight.
    """

    try:
        result = get_ocean_context_engine().build_context(
            mode=mode,
            ocean=ocean,
            latitude=None if latitude is None else float(latitude),
            longitude=None if longitude is None else float(longitude),
            radius_km=float(radius_km),
            variable=variable,
            reference_time_utc=reference_time_utc,
            past_hours=float(past_hours),
            future_hours=float(future_hours),
            include_sensors=bool(include_sensors),
            sensor_limit=int(sensor_limit),
        )
        result["api"] = {
            "version": "1.0",
            "endpoint": "/api/v1/ocean/context",
            "synthetic_data": False,
            "interpolation": False,
        }
        return result

    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Unified ocean context unavailable: {exc}",
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Unified ocean context query failed: {exc}",
        ) from exc


# =============================================================================
# NAVIGATION ROUTE
# =============================================================================

@app.post(
    "/api/v1/navigation/route",
    response_model=NavigationResult,
)
def navigation_route(
    request: NavigationRequest,
) -> NavigationResult:
    """
    Calculate a real-data 4D navigation route.

    Navigation is common to all OceanSight-V operational modes:

        disaster
        logistics
        fisheries
        naval

    The supplied NavigationRequest selects the operating mode.

    Temporal integrity:

        request.departure_time_utc
            = physical vessel departure time

        HYCOM model time
            = exact real INCOIS HYCOM source TIME

    The navigation engine performs no synthetic-data fallback
    and no interpolation.
    """

    try:

        navigation_engine = (
            get_navigation_engine()
        )

        result = navigation_engine.route(
            request
        )

        return result

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Navigation scientific engine unavailable: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Navigation route calculation failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# ARGO LOCAL PROFILE DISCOVERY HELPER
# =============================================================================

def _local_argo_discovery(
    latitude: float,
    longitude: float,
    radius_degrees: float,
    time_utc: str | None,
    platform_number: str | None,
    cycle_number: int | None,
    limit: int,
) -> dict[str, Any]:

    return argo_engine.discover_profiles(
        latitude=latitude,
        longitude=longitude,
        radius_degrees=radius_degrees,
        time_utc=time_utc,
        platform_number=platform_number,
        cycle_number=cycle_number,
        limit=limit,
    )


# =============================================================================
# ARGO PROFILE DISCOVERY
# =============================================================================

@app.get(
    "/api/v1/argo/profiles",
    response_model=ArgoProfileDiscoveryResponse,
)
def argo_profiles(
    latitude: float = Query(
        ...,
        ge=-90.0,
        le=90.0,
        description=(
            "Center latitude in degrees."
        ),
    ),

    longitude: float = Query(
        ...,
        ge=-180.0,
        le=180.0,
        description=(
            "Center longitude in degrees."
        ),
    ),

    radius_degrees: float = Query(
        default=5.0,
        gt=0.0,
        le=20.0,
        description=(
            "Argo profile discovery radius in degrees."
        ),
    ),

    time_utc: str | None = Query(
        default=None,
        description=(
            "Optional exact Argo profile time."
        ),
    ),

    platform_number: str | None = Query(
        default=None,
        description=(
            "Optional Argo platform number."
        ),
    ),

    cycle_number: int | None = Query(
        default=None,
        ge=0,
        description=(
            "Optional Argo cycle number."
        ),
    ),

    limit: int = Query(
        default=100,
        ge=1,
        le=1000,
        description=(
            "Maximum number of profiles."
        ),
    ),
) -> dict[str, Any]:

    try:

        normalized_time = None

        if time_utc is not None:

            normalized_time = (
                validate_time_utc(
                    time_utc
                )
            )

        normalized_platform = (
            None
            if platform_number is None
            else str(
                platform_number
            ).strip()
        )

        normalized_cycle = (
            None
            if cycle_number is None
            else int(
                cycle_number
            )
        )

        # ---------------------------------------------------------------------
        # FIRST: query local real observations.
        # ---------------------------------------------------------------------

        local_result = (
            _local_argo_discovery(
                latitude=float(
                    latitude
                ),

                longitude=float(
                    longitude
                ),

                radius_degrees=float(
                    radius_degrees
                ),

                time_utc=normalized_time,

                platform_number=(
                    normalized_platform
                ),

                cycle_number=(
                    normalized_cycle
                ),

                limit=int(
                    limit
                ),
            )
        )

        local_profiles = local_result.get(
            "profiles",
            [],
        )

        # ---------------------------------------------------------------------
        # SECOND: if local store has no profiles, use the live INCOIS source.
        # ---------------------------------------------------------------------

        acquisition = None

        profiles = local_profiles

        if not profiles:

            live_result = (
                argo_live_manager.discover_profiles(
                    latitude=float(
                        latitude
                    ),

                    longitude=float(
                        longitude
                    ),

                    radius_degrees=float(
                        radius_degrees
                    ),

                    time_utc=normalized_time,

                    time_window_days=30.0,

                    limit=int(
                        limit
                    ),
                )
            )

            profiles = live_result.get(
                "profiles",
                []
            )

            acquisition = {
                "mode": "live",
                "automatic": True,
                "source": ARGO_SOURCE,
                "dataset": ARGO_DATASET,
                "available": bool(
                    profiles
                ),
            }

        else:

            acquisition = {
                "mode": "local",
                "automatic": False,
                "source": ARGO_SOURCE,
                "dataset": ARGO_DATASET,
                "available": True,
            }

        # ---------------------------------------------------------------------
        # Apply platform/cycle filtering to live discovery too.
        # ---------------------------------------------------------------------

        if normalized_platform:

            profiles = [
                profile
                for profile in profiles
                if str(
                    profile.get(
                        "platform_number"
                    )
                ).strip()
                == normalized_platform
            ]

        if normalized_cycle is not None:

            profiles = [
                profile
                for profile in profiles
                if int(
                    profile.get(
                        "cycle_number"
                    )
                )
                == normalized_cycle
            ]

        profiles = profiles[
            : int(limit)
        ]

        profile_summaries = []

        for profile in profiles:

            profile_summaries.append(
                {
                    "platform_number": str(
                        profile.get(
                            "platform_number"
                        )
                    ),

                    "cycle_number": int(
                        profile.get(
                            "cycle_number"
                        )
                    ),

                    "direction": profile.get(
                        "direction"
                    ),

                    "profile_time_utc": profile.get(
                        "profile_time_utc"
                    ),

                    "latitude": profile.get(
                        "latitude"
                    ),

                    "longitude": profile.get(
                        "longitude"
                    ),

                    "source_dataset": (
                        ARGO_DATASET
                    ),

                    "source": ARGO_SOURCE,

                    "available": True,
                }
            )

        return {
            "available": bool(
                profile_summaries
            ),

            "source": ARGO_SOURCE,

            "dataset": ARGO_DATASET,

            "request": {
                "latitude": float(
                    latitude
                ),

                "longitude": float(
                    longitude
                ),

                "radius_degrees": float(
                    radius_degrees
                ),

                "time_utc": normalized_time,

                "platform_number": (
                    normalized_platform
                ),

                "cycle_number": (
                    normalized_cycle
                ),

                "limit": int(
                    limit
                ),
            },

            "profiles": profile_summaries,

            "profile_count": len(
                profile_summaries
            ),

            "selected_profile": None,

            "scientific_rules": {
                "synthetic_data": False,

                "interpolation": False,

                "pressure_unit": "dbar",

                "pressure_is_depth": False,

                "pressure_converted_to_depth": False,
            },

            "provenance": {
                "source": ARGO_SOURCE,

                "dataset": ARGO_DATASET,

                "source_url": ARGO_SOURCE_URL,

                "acquisition": acquisition,

                "storage": (
                    "local SQLite or live INCOIS ERDDAP"
                ),

                "synthetic_data": False,

                "interpolation": False,
            },
        }

    except HTTPException:

        raise

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Argo profile discovery failed: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Argo profile discovery failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# ARGO COMPLETE PROFILE
# =============================================================================

@app.get(
    "/api/v1/argo/profile",
    response_model=ArgoProfileSeries,
)
def argo_profile(
    platform_number: str = Query(
        ...,
        min_length=1,
        description=(
            "Real Argo platform number."
        ),
    ),

    cycle_number: int = Query(
        ...,
        ge=0,
        description=(
            "Real Argo cycle number."
        ),
    ),
) -> dict[str, Any]:

    try:

        normalized_platform = str(
            platform_number
        ).strip()

        normalized_cycle = int(
            cycle_number
        )

        if not normalized_platform:

            raise ValueError(
                "platform_number cannot be empty."
            )

        # ---------------------------------------------------------------------
        # FIRST: local real profile.
        # ---------------------------------------------------------------------

        local_profile = (
            argo_engine.get_profile_series(
                platform_number=(
                    normalized_platform
                ),

                cycle_number=(
                    normalized_cycle
                ),
            )
        )

        if local_profile.get(
            "available"
        ):

            local_profile[
                "live_acquisition"
            ] = {
                "used": False,

                "mode": "local",

                "automatic": False,

                "source": ARGO_SOURCE,

                "dataset": ARGO_DATASET,
            }

            return local_profile

        # ---------------------------------------------------------------------
        # SECOND: live INCOIS profile acquisition.
        # ---------------------------------------------------------------------

        live_acquisition = (
            argo_live_manager.acquire_profile(
                platform_number=(
                    normalized_platform
                ),

                cycle_number=(
                    normalized_cycle
                ),
            )
        )

        if not live_acquisition.get(
            "available"
        ):

            raise HTTPException(
                status_code=404,
                detail=(
                    "No real Argo profile was found "
                    f"for platform {normalized_platform}, "
                    f"cycle {normalized_cycle}."
                ),
            )

        # ---------------------------------------------------------------------
        # Refresh from SQLite after live acquisition.
        # ---------------------------------------------------------------------

        refreshed_profile = (
            argo_engine.get_profile_series(
                platform_number=(
                    normalized_platform
                ),

                cycle_number=(
                    normalized_cycle
                ),
            )
        )

        if not refreshed_profile.get(
            "available"
        ):

            raise RuntimeError(
                "Live Argo profile was acquired successfully, "
                "but the refreshed local profile could not be read."
            )

        refreshed_profile[
            "live_acquisition"
        ] = {
            "used": True,

            "mode": "live",

            "automatic": True,

            "source": ARGO_SOURCE,

            "dataset": ARGO_DATASET,

            "acquisition": live_acquisition,
        }

        refreshed_profile[
            "scientific_rules"
        ] = {
            "pressure_unit": "dbar",

            "pressure_is_depth": False,

            "pressure_converted_to_depth": False,

            "synthetic_data": False,

            "interpolation": False,
        }

        return refreshed_profile

    except HTTPException:

        raise

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Argo profile acquisition/query failed: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Argo profile acquisition/query failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# OCEAN POINT
# =============================================================================

@app.get(
    "/api/v1/ocean/point",
    response_model=OceanPointResponse,
)
def ocean_point(
    latitude: float = Query(
        ...,
        ge=-90.0,
        le=90.0,
        description=(
            "Requested latitude in degrees."
        ),
    ),

    longitude: float = Query(
        ...,
        ge=-180.0,
        le=180.0,
        description=(
            "Requested longitude in degrees."
        ),
    ),

    depth_m: float = Query(
        ...,
        ge=0.0,
        description=(
            "Requested HYCOM depth in meters."
        ),
    ),

    time_utc: str = Query(
        ...,
        description=(
            "Requested ocean-state time as an "
            "ISO-8601 UTC timestamp."
        ),
    ),

    argo_pressure_dbar: float | None = Query(
        default=None,
        ge=0.0,
        description=(
            "Optional requested Argo pressure in dbar."
        ),
    ),

    argo_radius_degrees: float = Query(
        default=2.0,
        gt=0.0,
        le=20.0,
        description=(
            "Argo search radius in geographic degrees."
        ),
    ),
) -> dict[str, Any]:

    try:

        normalized_time_utc = (
            validate_time_utc(
                time_utc
            )
        )

        result = engine.query(
            latitude=float(
                latitude
            ),

            longitude=float(
                longitude
            ),

            depth_m=float(
                depth_m
            ),

            time_utc=normalized_time_utc,

            argo_pressure_dbar=(
                None
                if argo_pressure_dbar
                is None
                else float(
                    argo_pressure_dbar
                )
            ),

            argo_radius_degrees=float(
                argo_radius_degrees
            ),
        )

        result["api"] = {
            "version": "1.0",

            "endpoint": (
                "/api/v1/ocean/point"
            ),

            "live_acquisition_enabled": True,

            "synthetic_data": False,

            "interpolation": False,
        }

        return result

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "Scientific data acquisition/query failed: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Scientific query failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# OCEAN SLICE
# =============================================================================

@app.get(
    "/api/v1/ocean/slice",
)
def ocean_slice(
    latitude_min: float = Query(
        ...,
        ge=-90.0,
        le=90.0,
    ),

    latitude_max: float = Query(
        ...,
        ge=-90.0,
        le=90.0,
    ),

    longitude_min: float = Query(
        ...,
        ge=-180.0,
        le=180.0,
    ),

    longitude_max: float = Query(
        ...,
        ge=-180.0,
        le=180.0,
    ),

    depth_m: float = Query(
        ...,
        ge=0.0,
    ),

    time_utc: str = Query(
        ...,
    ),

    variable: str = Query(
        default="TEMP",
    ),
) -> dict[str, Any]:

    try:

        normalized_time_utc = (
            validate_time_utc(
                time_utc
            )
        )

        result = (
            slice_engine.query_dict(
                latitude_min=float(
                    latitude_min
                ),

                latitude_max=float(
                    latitude_max
                ),

                longitude_min=float(
                    longitude_min
                ),

                longitude_max=float(
                    longitude_max
                ),

                depth_m=float(
                    depth_m
                ),

                time_utc=normalized_time_utc,

                variable=str(
                    variable
                ).strip().upper(),
            )
        )

        result["api"] = {
            "version": "1.0",

            "endpoint": (
                "/api/v1/ocean/slice"
            ),

            "live_acquisition_enabled": False,

            "synthetic_data": False,

            "interpolation": False,

            "local_chunk_backed": True,
        }

        return result

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except LookupError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=(
                "HYCOM slice query failed: "
                f"{exc}"
            ),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "HYCOM slice query failed: "
                f"{exc}"
            ),
        ) from exc


# =============================================================================
# LOCAL DEVELOPMENT SERVER
# =============================================================================

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(
        "app.api:app",
        host="127.0.0.1",
        port=8001,
        reload=False,
    )
@app.get("/api/v1/ocean/global")
def ocean_global(
    time_utc: str = Query(...),
    variable: str = Query(default="temperature"),
    latitude_min: float = Query(-80.0, ge=-90.0, le=90.0),
    latitude_max: float = Query(80.0, ge=-90.0, le=90.0),
    longitude_min: float = Query(-180.0, ge=-180.0, le=180.0),
    longitude_max: float = Query(180.0, ge=-180.0, le=180.0),
    depth_m: float | None = Query(default=None, ge=0.0),
    ocean: str | None = Query(default=None),
) -> dict[str, Any]:
    if latitude_min > latitude_max or longitude_min > longitude_max:
        raise HTTPException(status_code=400, detail="Bounding-box minimum cannot exceed maximum.")
    try:
        result = get_ocean_data_engine().build_data(
            mode="ocean", ocean=ocean, latitude=None, longitude=None, radius_km=50.0,
            time_utc=validate_time_utc(time_utc), variable=variable,
            depths_m=None if depth_m is None else [depth_m],
            bbox={"latitude_min": latitude_min, "latitude_max": latitude_max,
                  "longitude_min": longitude_min, "longitude_max": longitude_max},
        )
        result["api"] = {"version": "1.0", "endpoint": "/api/v1/ocean/global", "synthetic_data": False, "interpolation": False}
        return result
    except (ValueError, LookupError, NotImplementedError, FileNotFoundError, RuntimeError) as exc:
        code = 400 if isinstance(exc, ValueError) else 404 if isinstance(exc, LookupError) else 501 if isinstance(exc, NotImplementedError) else 503
        raise HTTPException(status_code=code, detail=str(exc)) from exc

# =============================================================================
# OCEAN BINARY TILE
# =============================================================================


@app.get(
    "/api/v1/ocean/tile",
)
def ocean_tile(
    level: int = Query(
        default=0,
        ge=0,
        le=6,
        description="Global tile detail level.",
    ),
    x: int = Query(
        default=0,
        ge=0,
        description="Horizontal tile index.",
    ),
    y: int = Query(
        default=0,
        ge=0,
        description="Vertical tile index.",
    ),
    time_utc: str = Query(
        ...,
        description="Exact real HYCOM source timestamp.",
    ),
    variable: str = Query(
        default="TEMP",
        description="HYCOM variable code.",
    ),
    depth_m: float = Query(
        default=0.0,
        ge=0.0,
        description="Requested depth in meters.",
    ),
) -> Response:
    """
    Return one compact binary ocean tile.

    Binary layout:

        uint64 little-endian metadata length
        UTF-8 JSON metadata
        Float32 values
        Uint8 missing mask

    The existing global, volume, slice, and data endpoints are unchanged.
    """

    try:
        normalized_time = validate_time_utc(
            time_utc,
        )

        metadata, payload = ocean_tile_engine.build_tile(
            level=int(level),
            x=int(x),
            y=int(y),
            time_utc=normalized_time,
            variable=str(variable).strip().upper(),
            depth_m=float(depth_m),
        )

        return Response(
            content=payload,
            media_type="application/octet-stream",
            headers={
                "Cache-Control": "public, max-age=300",
                "X-OceanSight-Tile-Format": "oceansight-f32-v1",
                "X-OceanSight-Tile-Level": str(metadata["level"]),
                "X-OceanSight-Tile-X": str(metadata["x"]),
                "X-OceanSight-Tile-Y": str(metadata["y"]),
            },
        )

    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except LookupError as exc:
        raise HTTPException(
            status_code=404,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail=str(exc),
        ) from exc

    except RuntimeError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Ocean tile scientific engine unavailable: {exc}",
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Ocean tile query failed: {exc}",
        ) from exc