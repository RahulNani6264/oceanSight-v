from __future__ import annotations

import math
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import numpy as np
import xarray as xr

from .ocean_geometry import OceanGeometryEngine


NOAA_GFS_BASE = "https://upwell.pfeg.noaa.gov/erddap/griddap/NCEP_Global_Best"
NOAA_CHL_BASE = "https://coastwatch.noaa.gov/erddap/griddap/noaacwNPPN20VIIRSDINEOFDaily"


@dataclass(frozen=True)
class ExternalVariableConfig:
    variable_id: str
    dataset_id: str
    base_url: str
    source_name: str
    source_provider: str
    field: str
    unit: str
    dimensions: tuple[str, ...]
    is_forecast_capable: bool
    ocean_surface_only: bool
    source_note: str


CONFIGS: dict[str, ExternalVariableConfig] = {
    "wind": ExternalVariableConfig(
        variable_id="wind",
        dataset_id="NCEP_Global_Best",
        base_url=NOAA_GFS_BASE,
        source_name="NOAA/NCEP Global Forecast System (GFS)",
        source_provider="NOAA NCEP",
        field="ugrd10m,vgrd10m",
        unit="m/s",
        dimensions=("time", "latitude", "longitude"),
        is_forecast_capable=True,
        ocean_surface_only=True,
        source_note="10 m eastward and northward wind components from the global GFS forecast collection.",
    ),
    "air_pressure": ExternalVariableConfig(
        variable_id="air_pressure",
        dataset_id="NCEP_Global_Best",
        base_url=NOAA_GFS_BASE,
        source_name="NOAA/NCEP Global Forecast System (GFS)",
        source_provider="NOAA NCEP",
        field="prmslmsl",
        unit="hPa",
        dimensions=("time", "latitude", "longitude"),
        is_forecast_capable=True,
        ocean_surface_only=True,
        source_note="Mean sea-level pressure from the global GFS forecast collection.",
    ),
    "chlorophyll": ExternalVariableConfig(
        variable_id="chlorophyll",
        dataset_id="noaacwNPPN20VIIRSDINEOFDaily",
        base_url=NOAA_CHL_BASE,
        source_name="NOAA CoastWatch / VIIRS S-NPP",
        source_provider="NOAA NESDIS CoastWatch",
        field="chlor_a",
        unit="mg/m^3",
        dimensions=("time", "altitude", "latitude", "longitude"),
        is_forecast_capable=False,
        ocean_surface_only=True,
        source_note="Gap-filled DINEOF near-real-time VIIRS chlorophyll-a, global 9 km daily product.",
    ),
}


class OceanExternalDataEngine:
    """Fetch real atmospheric and ocean-colour grids from public NOAA ERDDAP."""

    def __init__(
        self,
        *,
        geometry_engine: OceanGeometryEngine,
        timeout_seconds: float = 45.0,
    ) -> None:
        self.geometry_engine = geometry_engine
        self.timeout_seconds = float(timeout_seconds)

    @staticmethod
    def _normalize_lon(value: float) -> float:
        return ((float(value) + 180.0) % 360.0) - 180.0

    @staticmethod
    def _as_360(value: float) -> float:
        normalized = ((float(value) + 180.0) % 360.0) - 180.0
        return normalized if normalized >= 0 else normalized + 360.0

    @staticmethod
    def _validate_bbox(
        latitude_min: float,
        latitude_max: float,
        longitude_min: float,
        longitude_max: float,
    ) -> tuple[float, float, float, float]:
        lat_min = max(-90.0, min(90.0, float(latitude_min)))
        lat_max = max(-90.0, min(90.0, float(latitude_max)))
        if lat_min > lat_max:
            lat_min, lat_max = lat_max, lat_min

        lon_min = float(longitude_min)
        lon_max = float(longitude_max)
        if not all(math.isfinite(value) for value in (lon_min, lon_max)):
            raise ValueError("Longitude bounds must be finite.")

        return lat_min, lat_max, lon_min, lon_max

    @staticmethod
    def _stride(
        lat_min: float,
        lat_max: float,
        lon_min: float,
        lon_max: float,
        *,
        resolution: float,
        max_points: int = 12000,
    ) -> int:
        lat_span = max(0.0, lat_max - lat_min)
        lon_span = max(0.0, lon_max - lon_min)
        estimated = max(1.0, (lat_span / resolution + 1.0) * (lon_span / resolution + 1.0))
        if estimated <= max_points:
            return 1
        return max(1, int(math.ceil(math.sqrt(estimated / max_points))))

    @staticmethod
    def _time_token(time_utc: str) -> str:
        return str(time_utc).strip().replace("+00:00", "Z")

    def _erddap_url(
        self,
        *,
        config: ExternalVariableConfig,
        time_utc: str,
        latitude_min: float,
        latitude_max: float,
        longitude_min: float,
        longitude_max: float,
        stride: int,
    ) -> str:
        time_token = self._time_token(time_utc)
        lat_hi = max(latitude_min, latitude_max)
        lat_lo = min(latitude_min, latitude_max)
        lon_start = self._as_360(longitude_min)
        lon_stop = self._as_360(longitude_max)

        # GFS and the NOAA VIIRS product both expose a 0..360 longitude axis.
        # For requests that cross 0/360, constrain the full longitude range;
        # the returned source grid is still masked by the selected ocean geometry.
        if lon_stop < lon_start:
            lon_start, lon_stop = 0.0, 359.5

        lat_range = f"[{lat_hi}]:{stride}:[{lat_lo}]"
        lon_range = f"[{lon_start}]:{stride}:[{lon_stop}]"

        if config.variable_id == "chlorophyll":
            query = (
                f"{config.field}[({time_token})][(0)]"
                f"[{lat_range[1:]}][{lon_range[1:]}]"
            )
        elif config.variable_id == "wind":
            query = (
                f"ugrd10m[({time_token})][{lat_range}][{lon_range}],"
                f"vgrd10m[({time_token})][{lat_range}][{lon_range}]"
            )
        else:
            query = f"{config.field}[({time_token})][{lat_range}][{lon_range}]"

        return f"{config.base_url}.nc?{query}"

    @staticmethod
    def _load_netcdf(content: bytes) -> xr.Dataset:
        with tempfile.NamedTemporaryFile(suffix=".nc", delete=False) as handle:
            handle.write(content)
            temp_path = Path(handle.name)
        try:
            dataset = xr.open_dataset(temp_path)
            return dataset.load()
        finally:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass

    def _download(self, url: str) -> xr.Dataset:
        try:
            with httpx.Client(timeout=self.timeout_seconds, follow_redirects=True) as client:
                response = client.get(url)
                response.raise_for_status()
        except httpx.HTTPError as exc:
            raise RuntimeError(
                f"External NOAA ERDDAP request failed: {exc}"
            ) from exc
        return self._load_netcdf(response.content)

    @staticmethod
    def _to_numpy(values: Any) -> np.ndarray:
        array = np.asarray(values)
        if np.ma.isMaskedArray(array):
            array = array.filled(np.nan)
        return array

    @staticmethod
    def _json_grid(array: np.ndarray) -> list[list[float | None]]:
        result: list[list[float | None]] = []
        for row in np.asarray(array):
            output_row: list[float | None] = []
            for value in np.asarray(row).reshape(-1):
                numeric = float(value)
                output_row.append(numeric if math.isfinite(numeric) else None)
            result.append(output_row)
        return result

    def _geometry_water_mask(
        self,
        *,
        ocean: str,
        latitudes: np.ndarray,
        longitudes: np.ndarray,
    ) -> list[list[bool]]:
        boundary = self.geometry_engine.boundary(ocean)
        if boundary.geometry is None:
            return [[True for _ in longitudes] for _ in latitudes]

        try:
            from shapely.geometry import Point, shape
            polygon = shape(boundary.geometry)
        except ImportError as exc:
            raise RuntimeError(
                "shapely is required for external-data water masking."
            ) from exc

        mask: list[list[bool]] = []
        for latitude in latitudes:
            row: list[bool] = []
            for longitude in longitudes:
                lon = float(longitude)
                if lon > 180.0:
                    lon -= 360.0
                row.append(bool(polygon.covers(Point(lon, float(latitude)))))
            mask.append(row)
        return mask

    def build_data(
        self,
        *,
        ocean: str,
        latitude_min: float,
        latitude_max: float,
        longitude_min: float,
        longitude_max: float,
        time_utc: str,
        variable: str,
    ) -> dict[str, Any]:
        canonical = str(variable).strip().lower()
        if canonical not in CONFIGS:
            raise ValueError(f"Unsupported external variable: {variable}")

        config = CONFIGS[canonical]
        lat_min, lat_max, lon_min, lon_max = self._validate_bbox(
            latitude_min, latitude_max, longitude_min, longitude_max
        )

        resolution = 0.5 if config.dataset_id == "NCEP_Global_Best" else 0.0833333333
        stride = self._stride(
            lat_min,
            lat_max,
            lon_min,
            lon_max,
            resolution=resolution,
        )
        url = self._erddap_url(
            config=config,
            time_utc=time_utc,
            latitude_min=lat_min,
            latitude_max=lat_max,
            longitude_min=lon_min,
            longitude_max=lon_max,
            stride=stride,
        )
        dataset = self._download(url)
        try:
            latitudes = self._to_numpy(dataset["latitude"].values).reshape(-1)
            longitudes = self._to_numpy(dataset["longitude"].values).reshape(-1)

            water_mask = self._geometry_water_mask(
                ocean=ocean,
                latitudes=latitudes,
                longitudes=longitudes,
            )

            if canonical == "wind":
                u = self._to_numpy(dataset["ugrd10m"].values)
                v = self._to_numpy(dataset["vgrd10m"].values)
                u = np.squeeze(u)
                v = np.squeeze(v)
                speed = np.hypot(u, v)
                direction = np.degrees(np.arctan2(v, u))
                direction = np.mod(direction, 360.0)

                levels = [
                    self._level("wind_u", "m/s", u, latitudes, longitudes, water_mask),
                    self._level("wind_v", "m/s", v, latitudes, longitudes, water_mask),
                    self._level("wind_speed", "m/s", speed, latitudes, longitudes, water_mask),
                    self._level("wind_direction", "degree", direction, latitudes, longitudes, water_mask),
                ]
            elif canonical == "air_pressure":
                pressure_pa = np.squeeze(self._to_numpy(dataset["prmslmsl"].values))
                pressure_hpa = pressure_pa / 100.0
                levels = [
                    self._level(
                        "air_pressure",
                        "hPa",
                        pressure_hpa,
                        latitudes,
                        longitudes,
                        water_mask,
                    )
                ]
            else:
                chlorophyll = np.squeeze(self._to_numpy(dataset["chlor_a"].values))
                levels = [
                    self._level(
                        "chlorophyll",
                        "mg/m^3",
                        chlorophyll,
                        latitudes,
                        longitudes,
                        water_mask,
                    )
                ]

            actual_time = None
            if "time" in dataset.coords and dataset["time"].size:
                actual_time = str(dataset["time"].values.reshape(-1)[0])

            return {
                "available": True,
                "variable_id": canonical,
                "data_kind": "external_surface_grid",
                "source": {
                    "provider": config.source_provider,
                    "dataset": config.dataset_id,
                    "field": config.field,
                    "service": "public NOAA ERDDAP",
                    "source_note": config.source_note,
                    "request_url": url,
                },
                "request": {
                    "ocean": ocean,
                    "latitude_min": lat_min,
                    "latitude_max": lat_max,
                    "longitude_min": lon_min,
                    "longitude_max": lon_max,
                    "time_utc": time_utc,
                    "stride": stride,
                },
                "actual_time_utc": actual_time,
                "levels": levels,
                "water_mask": water_mask,
                "scientific_rules": {
                    "synthetic_data": False,
                    "interpolation": False,
                    "source_grid_values": True,
                    "ocean_region_mask_applied": True,
                },
            }
        finally:
            dataset.close()

    @staticmethod
    def _level(
        output_name: str,
        units: str,
        values: np.ndarray,
        latitudes: np.ndarray,
        longitudes: np.ndarray,
        water_mask: list[list[bool]],
    ) -> dict[str, Any]:
        values = np.asarray(values, dtype=float)
        while values.ndim > 2:
            values = values[0]
        masked = values.copy()
        for row_index in range(masked.shape[0]):
            for column_index in range(masked.shape[1]):
                if not water_mask[row_index][column_index]:
                    masked[row_index, column_index] = np.nan

        finite = masked[np.isfinite(masked)]
        return {
            "output_name": output_name,
            "units": units,
            "depth_m": 0.0,
            "latitudes": [float(value) for value in latitudes],
            "longitudes": [float(value) for value in longitudes],
            "values": OceanExternalDataEngine._json_grid(masked),
            "missing_mask": [
                [not math.isfinite(float(value)) for value in row]
                for row in masked
            ],
            "water_mask": water_mask,
            "valid_value_count": int(finite.size),
            "min": float(np.min(finite)) if finite.size else None,
            "max": float(np.max(finite)) if finite.size else None,
        }


__all__ = ["OceanExternalDataEngine", "CONFIGS", "ExternalVariableConfig"]
